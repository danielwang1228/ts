package com.cqfy.disruptor;

import com.cqfy.disruptor.util.Util;

import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;



/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/27
 * @Description:消费池，其实就是把所有的消费者处理器，也就相当于消费者线程一起管理了
 */
public final class WorkerPool<T>
{
    //消费池是否启动的标志
    private final AtomicBoolean started = new AtomicBoolean(false);

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:这个属性相当重要，就是用来给WorkerPool管理的每一个消费者分配消费序号的
     * 每当消费者希望能消费一个生产者数据时，都要去下面这个workSequence中申请。workSequence代表的就是
     * 已经分配到的消费进度，比如现在生产者发布的进度为15，而workSequence已经分配到7了，那么每一个
     * 消费者竞争消费这些生产者数据时，都会让workSequence来给它们分配可消费序号。比如现在一共有3个消费者要消费
     * 下一个数据了，因为是竞争消费，这就意味着下一个要消费的序号为8，所以这三个消费者
     * 线程消费下一个序号的生产者数据时，都会去workSequence中竞争下一个序号，竞争成功的话，就用CAS把workSequence
     * 可分配的消费进度更新一下，其实就是加1
     */
    private final Sequence workSequence = new Sequence(Sequencer.INITIAL_CURSOR_VALUE);

    //环形数组
    private final RingBuffer<T> ringBuffer;

    //工作处理器数组，数组中的每一个工作处理器都对应一个消费着，因为WorkProcessor
    //会包装用户定义的handler
    private final WorkProcessor<?>[] workProcessors;

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:构造方法
     */
    @SafeVarargs
    public WorkerPool(
            final RingBuffer<T> ringBuffer,
            final SequenceBarrier sequenceBarrier,
            final ExceptionHandler<? super T> exceptionHandler,
            final WorkHandler<? super T>... workHandlers)
    {   //环形数组赋值
        this.ringBuffer = ringBuffer;
        //得到用户定义的handler的数量
        final int numWorkers = workHandlers.length;
        //创建工作数组
        workProcessors = new WorkProcessor[numWorkers];
        //给工作数组的每一个位置初始化WorkProcessor对象
        for (int i = 0; i < numWorkers; i++)
        {   //在这里，数组的初始化就完成了，也就意味着WorkerPool管理了用户定义的所有消费处理器
            workProcessors[i] = new WorkProcessor<>(
                    ringBuffer,
                    sequenceBarrier,
                    workHandlers[i],
                    exceptionHandler,
                    workSequence);
        }
    }


    @SafeVarargs
    public WorkerPool(
            final EventFactory<T> eventFactory,
            final ExceptionHandler<? super T> exceptionHandler,
            final WorkHandler<? super T>... workHandlers)
    {
        ringBuffer = RingBuffer.createMultiProducer(eventFactory, 1024, new BlockingWaitStrategy());
        final SequenceBarrier barrier = ringBuffer.newBarrier();
        final int numWorkers = workHandlers.length;
        workProcessors = new WorkProcessor[numWorkers];

        for (int i = 0; i < numWorkers; i++)
        {
            workProcessors[i] = new WorkProcessor<>(
                    ringBuffer,
                    barrier,
                    workHandlers[i],
                    exceptionHandler,
                    workSequence);
        }

        ringBuffer.addGatingSequences(getWorkerSequences());
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:返回WorkerPool管理的每一个消费者的消费进度，以及WorkerPool自身中的workSequence的进度
     */
    public Sequence[] getWorkerSequences()
    {
        final Sequence[] sequences = new Sequence[workProcessors.length + 1];
        for (int i = 0, size = workProcessors.length; i < size; i++)
        {
            sequences[i] = workProcessors[i].getSequence();
        }
        sequences[sequences.length - 1] = workSequence;

        return sequences;
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:启动消费者池，其实就是为每一个workProcessors启动一个线程，然后执行workProcessors任务
     */
    public RingBuffer<T> start(final Executor executor)
    {
        if (!started.compareAndSet(false, true))
        {
            throw new IllegalStateException("WorkerPool has already been started and cannot be restarted until halted.");
        }
        //得到当前生产者的生产进度
        final long cursor = ringBuffer.getCursor();
        //给workSequence赋值，代表着现在这么多消费者，最多可以消费到cursor这个进度
        workSequence.set(cursor);
        for (WorkProcessor<?> processor : workProcessors)
        {   //给管理的每一个消费者的消费进度都赋成这个值
            processor.getSequence().set(cursor);
            //启动每一消费者线程
            executor.execute(processor);
        }
        return ringBuffer;
    }

    //等待消费完了所有生产者数据后再停止所有消费者线程
    public void drainAndHalt()
    {
        Sequence[] workerSequences = getWorkerSequences();
        while (ringBuffer.getCursor() > Util.getMinimumSequence(workerSequences))
        {
            Thread.yield();
        }
        for (WorkProcessor<?> processor : workProcessors)
        {
            processor.halt();
        }
        started.set(false);
    }

    //下面这两个方法第一版本都讲过了，就不再写注释了
    public void halt()
    {
        for (WorkProcessor<?> processor : workProcessors)
        {
            processor.halt();
        }
        started.set(false);
    }

    public boolean isRunning()
    {
        return started.get();
    }
}
