package com.cqfy.disruptor;

import java.util.concurrent.TimeUnit;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/10/14
 * @Description:这个阻塞策略定义的有些麻烦，并不是说逻辑复杂，而是分的情况比较多
 */
public final class PhasedBackoffWaitStrategy implements WaitStrategy
{   //默认的自旋次数
    private static final int SPIN_TRIES = 10000;
    //自旋超时时间
    private final long spinTimeoutNanos;
    //让出CPU超时时间
    private final long yieldTimeoutNanos;
    //在自旋超时和让出CPU超时后，调用这个阻塞策略，阻塞线程
    private final WaitStrategy fallbackStrategy;

    //构造方法，在这里可以看出，自旋超时时间和让出CPU超时时间以及fallbackStrategy都是可以让用户自己指定的
    public PhasedBackoffWaitStrategy(
            long spinTimeout,
            long yieldTimeout,
            TimeUnit units,
            WaitStrategy fallbackStrategy)
    {
        this.spinTimeoutNanos = units.toNanos(spinTimeout);
        this.yieldTimeoutNanos = spinTimeoutNanos + units.toNanos(yieldTimeout);
        this.fallbackStrategy = fallbackStrategy;
    }


    public static PhasedBackoffWaitStrategy withLock(
            long spinTimeout,
            long yieldTimeout,
            TimeUnit units)
    {
        return new PhasedBackoffWaitStrategy(
                spinTimeout, yieldTimeout,
                units, new BlockingWaitStrategy());
    }


    public static PhasedBackoffWaitStrategy withLiteLock(
            long spinTimeout,
            long yieldTimeout,
            TimeUnit units)
    {
        return new PhasedBackoffWaitStrategy(
                spinTimeout, yieldTimeout,
                units, new LiteBlockingWaitStrategy());
    }


    public static PhasedBackoffWaitStrategy withSleep(
            long spinTimeout,
            long yieldTimeout,
            TimeUnit units)
    {
        return new PhasedBackoffWaitStrategy(
                spinTimeout, yieldTimeout,
                units, new SleepingWaitStrategy(0));
    }

    @Override
    public long waitFor(long sequence, Sequence cursor, Sequence dependentSequence, SequenceBarrier barrier)
            throws AlertException, InterruptedException, TimeoutException
    {
        long availableSequence;
        long startTime = 0;
        //得到默认的自旋次数
        int counter = SPIN_TRIES;
        do {
            if ((availableSequence = dependentSequence.get()) >= sequence) {
                return availableSequence;
            }
            //如果要阻塞，还是先让线程自旋，直到自旋了10000次再进入下面的分支
            //注意，在进入了下面的分支后，自旋次数就会被重新赋值，又会变成10000了
            if (0 == --counter) {
                //自旋了之后，线程还是要阻塞，就进入下面的分支，下面的分支其实还是要进行自旋
                //但是变成了限时自旋
                if (0 == startTime) {
                    //这里得到开始限时自旋的开始时间
                    startTime = System.nanoTime();
                }
                else {
                    //又经过自旋之后，执行到这里了，这里肯定就能得到一个自旋耗费的时间
                    long timeDelta = System.nanoTime() - startTime;
                    //如果距离让出CPU已经过的时间大于yieldTimeoutNanos了
                    //也就是已经让出CPU超时了，线程仍然不能继续向下执行
                    if (timeDelta > yieldTimeoutNanos) {
                        //这时候就调用其他的阻塞策略，让线程直接阻塞
                        //这里调用的就是BlockingWaitStrategy、LiteBlockingWaitStrategy、SleepingWaitStrategy三个阻塞策略中的一个
                        //让线程开始阻塞。为什么是这三个阻塞策略中的一个呢？因为在本类提供的构造方法中
                        //只实现了用这三个阻塞策略给fallbackStrategy成员变量赋值
                        return fallbackStrategy.waitFor(sequence, cursor, dependentSequence, barrier);
                    }
                    //如果自旋的时间大于限时自旋的时间了，就让出线程
                    else if (timeDelta > spinTimeoutNanos) {
                        //如果没让成功，肯定又会经历自旋
                        Thread.yield();
                    }
                }//在这里给自旋次数重新赋值为10000
                counter = SPIN_TRIES;
            }
        }
        while (true);
    }

    @Override
    public void signalAllWhenBlocking()
    {
        fallbackStrategy.signalAllWhenBlocking();
    }
}
