package com.cqfy.disruptor;

import com.cqfy.disruptor.util.ThreadHints;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/29
 * @Description:阻塞等待的类，并且没有限时，而TimeoutBlockingWaitStrategy类会有时间限制
 */
public final class BlockingWaitStrategy implements WaitStrategy
{
    private final Lock lock = new ReentrantLock();
    private final Condition processorNotifyCondition = lock.newCondition();

    @Override
    public long waitFor(long sequence, Sequence cursorSequence, Sequence dependentSequence, SequenceBarrier barrier)
            throws AlertException, InterruptedException
    {
        long availableSequence;
        //这里的逻辑分成了两部分，先用当前生产者的进度和消费者希望消费的下一个进度序号做判断
        //如果生产者进度小于要消费的消费者进度，那肯定就阻塞一会
        if (cursorSequence.get() < sequence)
        {
            lock.lock();
            try
            {
                while (cursorSequence.get() < sequence)
                {
                    barrier.checkAlert();
                    //没有限时的阻塞
                    processorNotifyCondition.await();
                }
            }
            finally
            {
                lock.unlock();
            }
        }//生产者进度判断完了，还要判断当前消费者依赖的其他消费者的消费进度是否小于当前消费者要消费的进度
        while ((availableSequence = dependentSequence.get()) < sequence)
        {
            barrier.checkAlert();
            //如果小于肯定也是阻塞一会，这里换了一种方式，使用的是线程自旋的方式来等待
            ThreadHints.onSpinWait();
        }
        return availableSequence;
    }


    //唤醒消费者的方法
    @Override
    public void signalAllWhenBlocking()
    {
        lock.lock();
        try
        {
            processorNotifyCondition.signalAll();
        }
        finally
        {
            lock.unlock();
        }
    }

    @Override
    public String toString()
    {
        return "BlockingWaitStrategy{" +
                "processorNotifyCondition=" + processorNotifyCondition +
                '}';
    }
}
