package com.cqfy.disruptor;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/23
 * @Description:这个类就是序号屏障，是个非常重要的类。就是这个类的对象在协调消费者和生产者的进度
 */
final class ProcessingSequenceBarrier implements SequenceBarrier
{
    //等待策略，既然是序号屏障在协调消费者和生产者的进度，那么当生产者没有发布数据，消费者没有事件可消费的时候
    //肯定就应该等待了，等待生产者继续发布了数据，消费者才能继续消费
    private final WaitStrategy waitStrategy;
    //这个成员变量其实不是第一版本代码的内容，但是很多地方都用到了，为了代码不报错，所以就先引入了，后面会详细讲解
    //现在只简单说一下，考虑到消费者的消费顺序，有的消费者需要等待别的消费者消费完了一些事件，这些消费者才能消费这些事件
    //所以，这里把当前消费者依赖的其他消费者的消费进度赋值给下面的属性了，只有等到其他消费者都消费，当前的消费者才能消费
    private final Sequence dependentSequence;
    //消费者是否要终止
    private volatile boolean alerted = false;
    //生产者的生产进度
    private final Sequence cursorSequence;
    //序号生成器，专门给生产者分配生产序号的
    private final Sequencer sequencer;

    //构造方法
    ProcessingSequenceBarrier(
            final Sequencer sequencer,
            final WaitStrategy waitStrategy,
            final Sequence cursorSequence,
            final Sequence[] dependentSequences)
    {
        this.sequencer = sequencer;
        this.waitStrategy = waitStrategy;
        this.cursorSequence = cursorSequence;
        //这里有一个判断，那就是dependentSequences的长度是否为0.在第一版本中默认是0，所以会直接进入下面的分支
        //把生产者的生产进度赋值给dependentSequence
        //因为当前消费者不依赖其他消费者的话，那么消费者消费数据，只用看看生产者的进度是否能够消费就行了
        //所以，这里把依赖的进度直接用生产者的生产进度赋值就行了
        if (0 == dependentSequences.length)
        {
            dependentSequence = cursorSequence;
        }
        else
        {   //在这里把决定消费顺序的注释放开了，第四版本新加的代码
            dependentSequence = new FixedSequenceGroup(dependentSequences);
        }

    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/23
     * @Description:该类的核心方法，sequence参数就是消费者期望可以消费的最小的序号，也就是可以消费的
     * 最小的生产者进度序号
     */
    @Override
    public long waitFor(final long sequence)
            throws AlertException, InterruptedException, TimeoutException
    {   //检查是否有消费者终止的信号
        checkAlert();
        //使用具体的等待策略来判断消费者可以消费的最大序号，返回的这个序号就是消费可以消费的最大序号
        long availableSequence = waitStrategy.waitFor(sequence, cursorSequence, dependentSequence, this);
        //下面这个判断就是看一下返回的最大序号是否比消费者申请的最小序号还小，算是一个保底操作吧
        //实际上不可能发生，如果真的发生了，那就还是返回availableSequence即可
        if (availableSequence < sequence)
        {
            return availableSequence;
        }
        //下面这里就是返回最大的可以消费的生产者序号，所以肯定是返回availableSequence呀
        //当然，这是在单生产者模式下。只有一个生产者，发布的序号一定是连续的
        //但是在多生产者情况下就不一定了，所以在多生产者情况下，必须判断最大序号之前的序号是不是连续的
        //比如说现在可消费的最大的生产者序号是9，那么9之前的可消费的序号必须为12345678，如果是12345 789而没有6
        //那就要在中间截断，返回5
        return sequencer.getHighestPublishedSequence(sequence, availableSequence);
    }

    //该方法在第一版本代码中没有被用到
    //在第四版本代码中就用到了，现在得到的就是在当前消费者之前的其他消费者的最慢消费进度
    @Override
    public long getCursor()
    {
        //在第一版本中，当前消费者没有其他要依赖的消费者组，不必关心其他消费者的消费进度
        //所以dependentSequence被生产者的进度赋值了，所以这里返回的就是生产者当前的进度
        return dependentSequence.get();
    }

    @Override
    public boolean isAlerted()
    {
        return alerted;
    }

    //该方法一旦被调用，就意味着消费者要被终止了，所以把alerted设置为true即可
    @Override
    public void alert()
    {
        alerted = true;
        //唤醒所有阻塞的消费者线程，以响应这个终止的信号
        waitStrategy.signalAllWhenBlocking();
    }

    @Override
    public void clearAlert()
    {
        alerted = false;
    }

    @Override
    public void checkAlert() throws AlertException
    {
        if (alerted)
        {
            throw AlertException.INSTANCE;
        }
    }
}