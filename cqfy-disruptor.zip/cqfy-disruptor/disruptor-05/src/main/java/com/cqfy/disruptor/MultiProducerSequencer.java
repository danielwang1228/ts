package com.cqfy.disruptor;

import com.cqfy.disruptor.util.Util;
import sun.misc.Unsafe;

import java.util.concurrent.locks.LockSupport;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/28
 * @Description:第三版本代码中新添加进来的核心类，就是多生产者模式下的序号生成器
 */
public final class MultiProducerSequencer extends AbstractSequencer
{
    //得到Unsafe对象
    private static final Unsafe UNSAFE = Util.getUnsafe();
    //得到数组中首个有效元素在数组中的偏移量
    private static final long BASE = UNSAFE.arrayBaseOffset(int[].class);
    //得到数组中每一个位置的内存大小，其实就是一个内存增量
    //现在显然操纵的是int数组，每一个int站4个字节，那么数组的每一个位置4个字节
    //这个成员变量和上面的成员变量配合使用，可以快速定位数组中的一个元素
    private static final long SCALE = UNSAFE.arrayIndexScale(int[].class);
    //还记得SingleProducerSequencerPad类中的cachedValue成员变量吗？
    //该变量是用来缓存所有消费者中，消费最慢的那个进度，但在多生产模式下，这个缓存最慢进度
    //的成员变量变成了Sequence，Sequence中有一个value，为什么不直接使用cachedValue呢？
    //说实话，我也没考虑出一个很合理的结果，如果说是因为这个值在多生产者模式下会被并发访问
    //但使用了Sequence对象，也不会解决什么并发问题，最多时更新该值的时候，可以选择是Volatile更新
    //还是延迟更新，以提高一点性能，也许为了提高的这点性能，就是真正原因吧
    //毕竟现在是多个生产者线程都要根据下面这个成员变量来判断是否可以获得进度序号
    private final Sequence gatingSequenceCache = new Sequence(Sequencer.INITIAL_CURSOR_VALUE);
    //真正用来表明生产者进度的数组，消费者消费生产者数据的时候，真正参考的是这个数组，这个数组中的数据如果是连续的
    //消费者才能消费。比如说，消费者得到的可消费的序号是8，当前的消费进度是3，那就意味着3到8之间
    //的数据都可以消费，但是在这个数组中，3到8之间并不连续，第6个位置没有被赋值，那么消费能消费的进度只能到6
    private final int[] availableBuffer;
    //用于计算上面那个数组下标的掩码
    private final int indexMask;
    //计算availableBuffer中可用标志圈数的辅助属性
    private final int indexShift;

    //构造方法
    public MultiProducerSequencer(int bufferSize, final WaitStrategy waitStrategy)
    {
        super(bufferSize, waitStrategy);
        //创建availableBuffer数组
        availableBuffer = new int[bufferSize];
        //得到掩码的值
        indexMask = bufferSize - 1;
        //举个例子，如果环形数组的长度是8，那这个值就是3
        indexShift = Util.log2(bufferSize);
        //在构造方法中，把数组中的所有位置都设置为不可消费
        initialiseAvailableBuffer();
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:判断是否有充足的容量分配需要的序号数量，注意这里只是判断是否有足够的容量，并不是真的要分配这么多序号
     */
    @Override
    public boolean hasAvailableCapacity(final int requiredCapacity)
    {   //这里会把缓存所有消费者进度的数组gatingSequences以及cursor.get当前分配到的序号
        //传到下一个方法中，requiredCapacity就是要求分配的序号个数
        return hasAvailableCapacity(gatingSequences, requiredCapacity, cursor.get());
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:真正判断是否有充足的容量分配需要的序号数量的方法，这个方法中有大量的逻辑和第一版本中
     * 讲解的SingleProducerSequencer类中的hasAvailableCapacity方法的逻辑相同，所以大家不用担心这个方法有多难
     */
    private boolean hasAvailableCapacity(Sequence[] gatingSequences, final int requiredCapacity, long cursorValue)
    {
        //这里的计算很重要，比如cursorValue的值是13，也就是当前分配到的序号是13了
        //比如说要申请的requiredCapacity是5，那么13加5是18
        //比如说bufferSize是8，那么最后得到的差值就是10
        //这是不是就意味着，申请之后的生产者进度实际上比整个环形数组的容量大了十个
        //也就是说生产者的进度在第一次填满环形数组后，还能进行第二次填满，然后还多出来两个要填冲
        long wrapPoint = (cursorValue + requiredCapacity) - bufferSize;
        //得到所有消费者中最慢的消费进度
        long cachedGatingSequence = gatingSequenceCache.get();
        //下面这种情况，是不是在第一版本的代码中见过，就在SingleProducerSequencer类的hasAvailableCapacity方法中
        //所以，这里我就直接把第一版本的注释搬运过来了，就不再重复写了
        //得到的最慢的消费者的消费进度，比如说就消费到序号9了，大家可以想一想，如果上面得到的这个wrapPoint小于0，是不是意味着
        //生产者连环形数组的一圈都还没有填充完呢，所以，不管消费者消费到哪里了，都不会出现覆盖还未被消费的数据的情况。就是生产者
        //填充了环形数组一圈了，然后将要填充的位置就要覆盖了消费者还未消费的数据，在wrapPoint小于0的时候，是不会出现的
        //如果wrapPoint大于0呢？说明加上要申请的序号requiredCapacity，生产者肯定已经填充了环形数组一圈了，再次填充
        //肯定就是和掩码做位元算，然后从数组头部重新填充，这就有可能把尚未消费的数据覆盖掉，所以，接下来，程序就要避免这种情况出现
        //在上面得到的wrapPoint结果是10，而现在最慢的消费者才消费到9，环形数组长度是8
        //加上之前填充的那一轮，这是不是意味生产者已经填充了两次环形数组，该填充第三次了，第三次要填充2个数据，正好是数组的0号位置和1号位置
        //恰好会把第二轮填充的0号位和1号位覆盖掉
        //而当前的消费者的消费进度是9，也就是填充的第二轮的0号位，1号位还未被消费，但是要被生产者覆盖了，这就很尴尬了，所以，我们要避免这种情况出现
        //注意啊，这里并没有真的覆盖，因为一切的基础都建立在这个要申请的requiredCapacity之上，这里只是判断能不能分配requiredCapacity数量的
        //序号供生产者使用，现在这种情况肯定就不能分配了呀，所以要采取一些措施
        //所以，下面就是判断了一下，wrapPoint > cachedGatingSequence说明会发生覆盖未消费的数据的情况
        //第二个判断cachedGatingSequence > cursorValue在这里就有可能成立了，在第一版本代码中我给大家说不会出现这种情况
        //但是在这里就有可能了，因为现在是多生产者环境，也就是多个线程来竞争生产者序号，而cursorValue是被Sequence包装的
        //也不会发生伪共享，所以如果不是Volatile更新其中的value值，那么这个cachedGatingSequence和cursorValue的值
        //都有可能被其他生产者线程修改了，而当前生产者线程不知道，拿到的是旧值，也可能是一新一旧，所以才会发生最慢的消费进度
        //反而大于当前的生产者进度
        if (wrapPoint > cachedGatingSequence || cachedGatingSequence > cursorValue)
        {
            //走到这里就意味着不能分配生产者序号，所以这里就是通过gatingSequences数组去得到最小的消费者进度
            //这时候得到的消费者进度有可能就是最新的
            long minSequence = Util.getMinimumSequence(gatingSequences, cursorValue);
            //这里就是把缓存的最慢进度更新一下，注意，这里我想再多说几句，现在是在多生产者线程环境下，这个值可能会被
            //多个线程同时操作，但是该值的更新并没有任何同步保障，也就是说当前线程只管更新自己看到的最小消费进度
            //至于这个值是不是和其他线程同步是没有保障的，也许另一个线程看到的最慢消费进度是6，而当前线程看到的是4
            //结果另一个线程把6已经设置进去了，而当前线程再次赋值成了4，这样一来似乎就会出现问题，对吧？
            //但是我请大家再仔细想想，这个问题其实并不会构成威胁，大不了就是不给当前线程分配生产者序号，或者说得
            //准确一点是晚分配一会，因为在下面真正分配序号的next方法中，生产者线程会在一个循环中等待
            //序号分配成功，而在等待的过程中，总会获得gatingSequenceCache的准确的值的
            gatingSequenceCache.set(minSequence);
            //这里就是获得了最新的gatingSequenceCache的值，当然，是当前线程能看见的最新的值
            //如果这个值仍然小于wrapPoint，说明还是会发生覆盖数据问题，那么直接返回false即可
            if (wrapPoint > minSequence)
            {
                return false;
            }
        }
        //走到这里意味着可以分配这么多序号
        return true;
    }

    //将生产者的进度序号指定为sequence
    @Override
    public void claim(long sequence)
    {
        cursor.set(sequence);
    }

    //申请一个可用的序号的方法
    @Override
    public long next()
    {
        return next(1);
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:申请指定数量的序号，交给生产者使用
     */
    @Override
    public long next(int n)
    {   //判断一下，申请的序号小于1抛出异常
        if (n < 1)
        {
            throw new IllegalArgumentException("n must be > 0");
        }
        //当前已经分配到的生产者序号
        long current;
        //接下来要分配到的生产者序号
        long next;
        do
        {   //得到当前分配到的生产者序号
            current = cursor.get();
            //加上用户要申请的序号个数，得到了要分配到的序号，比如得到的是10
            //其实就是意味着从cursor到10之间的序号，都可以被消费了
            next = current + n;
            //和hasAvailableCapacity方法中的逻辑一样，判断是不是会覆盖未消费的数据
            long wrapPoint = next - bufferSize;
            //得到当前线程看见的最慢的消费者进度
            long cachedGatingSequence = gatingSequenceCache.get();
            //这里的逻辑在hasAvailableCapacity方法中分析过了，就不再重复注释了
            if (wrapPoint > cachedGatingSequence || cachedGatingSequence > current)
            {
                //走到这里意味着会发生覆盖数据的情况，所以要去获得最新的最慢消费者进度，这个进度
                //很可能是比当前缓存的进度大的
                long gatingSequence = Util.getMinimumSequence(gatingSequences, current);
                //如果获得了最新的消费者进度还是会发生覆盖数据的情况
                if (wrapPoint > gatingSequence)
                {   //在这里等待
                    LockSupport.parkNanos(1);
                    //然后进入下一次循环，判断是否不会发生覆盖进度的情况了
                    continue;
                }
                //走到这里就意味着wrapPoint < gatingSequence，把最新的消费者进度更新一下
                //其实这里就可以去获得生产者序号了，就是用CAS去修改cursor的值，但是作者没有这样处理
                gatingSequenceCache.set(gatingSequence);
            }
            //走到这里就意味着不会发生覆盖数据的情况，那么直接去获得序号即可
            //当然，多线程情况下肯定是要用CAS来修改的，这时候cursor的值也就更新了
            else if (cursor.compareAndSet(current, next))
            {
                //修改数据成功，就可以直接推出循环了
                break;
            }
        }
        while (true);
        //返回分配到的序号
        return next;
    }

    //尝试申请1个可用的序号
    @Override
    public long tryNext() throws InsufficientCapacityException
    {
        return tryNext(1);
    }

    //尝试申请可用的n个序号,这个方法就不再分析了，逻辑都是重复的
    @Override
    public long tryNext(int n) throws InsufficientCapacityException
    {
        if (n < 1)
        {
            throw new IllegalArgumentException("n must be > 0");
        }
        long current;
        long next;
        do
        {
            current = cursor.get();
            next = current + n;

            if (!hasAvailableCapacity(gatingSequences, n, current))
            {
                throw InsufficientCapacityException.INSTANCE;
            }
        }
        while (!cursor.compareAndSet(current, next));
        return next;
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:得到剩余的环形数组的容量，这个逻辑和第一版本中单生产者序号生成器中同名方法的逻辑一样
     * 就不再重复注释了
     */
    @Override
    public long remainingCapacity()
    {
        //得到消费进度最慢的消费者的序号
        long consumed = Util.getMinimumSequence(gatingSequences, cursor.get());
        long produced = cursor.get();
        return getBufferSize() - (produced - consumed);
    }

    //把availableBuffer数组中的所有位置都设置为不可消费，其实就是把每一个值设置成-1
    private void initialiseAvailableBuffer()
    {
        for (int i = availableBuffer.length - 1; i != 0; i--)
        {
            setAvailableBufferValue(i, -1);
        }//把数组0号位置设置成-1
        setAvailableBufferValue(0, -1);
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:发布可以被消费的生产者序号的方法，然后通知其他消费者来消费
     * 注意，在多生产者模式中，该方法也是被ringBuffer调用的，最终会在ringBuffer中调用到下面这个方法
     *
     * private <A> void translateAndPublish(EventTranslatorOneArg<E, A> translator, long sequence, A arg0)
     *     {
     *         try
     *         {
     *             translator.translateTo(get(sequence), sequence, arg0);
     *         }
     *         finally
     *         {    下面这个方法在这里被调用了
     *             sequencer.publish(sequence);
     *         }
     *     }
     *     在单线程生产者中，在publish方法中只是更新了生产者的序号，也就是 cursor.set(sequence) 方法
     *     但是多线程生产者环境中，多个线程执行 cursor.set(sequence) 方法是会出现并发问题的，在该类的上面方法中
     *     都是使用CAS来该表 cursor的值的，所以才不会出现并发问题。但这里如果仍然是更新 cursor的值，就会出现并发问题了
     *     所以该框架的作者就用当前线程分配到的生产者序号，去更新availableBuffer数组中的值，这样就不会出现并发问题了
     *     可能有朋友会有疑问，明明在该类的next(n)方法中已经更新了cursor的值，为什么还要在这里更新
     *     我请大家注意一下，仅仅是更新了这个生产者序号是没用的，是需要真正把生产者数据填充到环形数组的对应位置的
     *     就是上面这行代码translator.translateTo(get(sequence), sequence, arg0)，但现在的情况是
     *     多个线程竞争生产者序号，有可能1号线程竞争到了5这个生产者序号，2号线程竞争到了9这个序号，2号线程已经把生产者
     *     数据写入到环形数组的对应位置了，但是1号线程还没写入，这样虽然生产者序号虽然更新到9了，但是5这个序号的数据并未填充
     *     如果这时候消费者直接得到了最新的可消费进度，也就是生产者的序号9，可是中间有数据是空的，显然就会出错
     *     所以要弄一个availableBuffer数组，用来把可以消费的位置连续起来
     */
    @Override
    public void publish(final long sequence)
    {   //这个方法就是把能消费的进度设置到availableBuffer数组中
        //一旦设置成功，就意味着真正的生产者数据被填充到环形数组的对应位置了
        setAvailable(sequence);
        //通知消费者来消费
        waitStrategy.signalAllWhenBlocking();
    }

    //通知其他消费者这个hi序号位置之前的数据都可以消费了
    @Override
    public void publish(long lo, long hi)
    {
        for (long l = lo; l <= hi; l++)
        {
            setAvailable(l);
        }
        waitStrategy.signalAllWhenBlocking();
    }

    //这个方法就是把能消费的进度设置到availableBuffer数组中
    private void setAvailable(final long sequence)
    {   //这里得到的就是生产者序号在availableBuffer数组中的下标索引以及对应的圈数
        setAvailableBufferValue(calculateIndex(sequence), calculateAvailabilityFlag(sequence));
    }

    //真正把能消费的进度设置到availableBuffer数组中的方法
    private void setAvailableBufferValue(int index, int flag)
    {   //快速定位到指定下标在数组中的位置
        long bufferAddress = (index * SCALE) + BASE;
        //把对应的圈数写到对应的位置
        UNSAFE.putOrderedInt(availableBuffer, bufferAddress, flag);
    }

    //判断该生产序号究竟可不可用
    @Override
    public boolean isAvailable(long sequence)
    {   //根据生产序号找到该序号在availableBuffer数组中的位置
        int index = calculateIndex(sequence);
        //计算该序号对应的数组的圈数
        int flag = calculateAvailabilityFlag(sequence);
        //根据index得到该位置在数组中的偏移量
        long bufferAddress = (index * SCALE) + BASE;
        //从数组中对应位置取出数据，判断是否和生产序号计算的相等，如果相等就可用
        return UNSAFE.getIntVolatile(availableBuffer, bufferAddress) == flag;
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/29
     * @Description:这个方法很重要啊，这个就是在多生产者模式下，判断序号是否连续可用的方法
     */
    @Override
    public long getHighestPublishedSequence(long lowerBound, long availableSequence)
    {
        for (long sequence = lowerBound; sequence <= availableSequence; sequence++)
        {
            if (!isAvailable(sequence))
            {   //走到这里意味着这个位置的序号还没有填充数据，那该序号就不可用
                return sequence - 1;
            }
        }
        return availableSequence;
    }

    //计算可用标志在availableBuffer数组中是第几圈的方法
    private int calculateAvailabilityFlag(final long sequence)
    {   //如果这里环形数组的长度是8，indexShift就是3，如果生产者序号是6，右移3，结果是0
        //其实换成二进制就一目了然了8的二进制是 前面省略...... 0000 1000，右移3位正好是1
        //如果生产者序号是9，说明是第一圈
        //如果生产者序号是17，右移3位，得到的就是2
        //17的二进制为 前面省略...... 0001 0001
        return (int) (sequence >>> indexShift);
    }

    //计算分配到的生产者序号在availableBuffer数组中的下标位置
    //这个availableBuffer数组和环形数组的长度是一样的
    private int calculateIndex(final long sequence)
    {
        return ((int) sequence) & indexMask;
    }
}
