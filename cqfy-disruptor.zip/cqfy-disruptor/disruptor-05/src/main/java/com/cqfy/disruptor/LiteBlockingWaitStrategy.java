package com.cqfy.disruptor;

import com.cqfy.disruptor.util.ThreadHints;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


//这个类中也是分成了两部分来判断消费者线程是否应该阻塞
public final class LiteBlockingWaitStrategy implements WaitStrategy
{
    private final Lock lock = new ReentrantLock();
    private final Condition processorNotifyCondition = lock.newCondition();
    //这个成员变量的作用非常简单，就是设定一个标志，看看是否有消费者阻塞了
    private final AtomicBoolean signalNeeded = new AtomicBoolean(false);

    @Override
    public long waitFor(long sequence, Sequence cursorSequence, Sequence dependentSequence, SequenceBarrier barrier)
            throws AlertException, InterruptedException
    {
        long availableSequence;
        //在这里判断消费者是否需要阻塞
        if (cursorSequence.get() < sequence)
        {
            lock.lock();
            try
            {
                do
                {
                    //如果需要阻塞，那就把signalNeeded设置为true
                    //如果这个signalNeeded被设置为false了，说明当前一定有消费者线程阻塞了
                    signalNeeded.getAndSet(true);
                    if (cursorSequence.get() >= sequence)
                    {
                        break;
                    }
                    barrier.checkAlert();
                    processorNotifyCondition.await();
                }
                while (cursorSequence.get() < sequence);
            }
            finally
            {
                lock.unlock();
            }
        }

        //判断另一种阻塞情况
        while ((availableSequence = dependentSequence.get()) < sequence)
        {
            barrier.checkAlert();
            //在这里自旋
            ThreadHints.onSpinWait();
        }

        return availableSequence;
    }

    //环形消费者线程的方法
    @Override
    public void signalAllWhenBlocking()
    {
        //先判断signalNeeded的值是否为true，如果不为true，说明没有消费者线程阻塞，也就不必进入下面的逻辑
        if (signalNeeded.getAndSet(false))
        {
            lock.lock();
            try
            {
                processorNotifyCondition.signalAll();
            }
            finally
            {
                lock.unlock();
            }
        }
    }

    @Override
    public String toString()
    {
        return "LiteBlockingWaitStrategy{" +
                "processorNotifyCondition=" + processorNotifyCondition +
                '}';
    }
}
