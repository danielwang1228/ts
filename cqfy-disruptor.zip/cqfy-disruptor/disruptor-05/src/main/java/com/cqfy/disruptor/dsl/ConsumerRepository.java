package com.cqfy.disruptor.dsl;

import com.cqfy.disruptor.*;

import java.util.*;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/18
 * @Description:消费者仓库类，用户在定义消费者的时候，创建的其实就是一个EventHandler，而这个handler会被包装成
 * EventProcessor对象。而EventProcessor对象和其包装的handler会被EventProcessorInfo对象包装到一起
 * 而现在的这个消费者仓库类，就是通过键值对的方式把handler和EventProcessorInfo对象一一对应起来
 */
class ConsumerRepository<T> implements Iterable<ConsumerInfo>
{

    //下面这两个Map就是一些信息的简单对应，大家看看就行
    //其实通过这两个Map就能看出来，这个消费者仓库说白了就是把所有消费者的信息收集到一起，处理的时候一起处理一下
    //其实可以看成Netty中的group，只是起一个管理的作用，真正干活的还是收集到的每一个消费者
    private final Map<EventHandler<?>, EventProcessorInfo<T>> eventProcessorInfoByEventHandler =
            new IdentityHashMap<>();

    private final Map<Sequence, ConsumerInfo> eventProcessorInfoBySequence =
            new IdentityHashMap<>();

    //这个集合存放的是ConsumerInfo对象，其实ConsumerInfo是个接口，它的实现类就是EventProcessorInfo对象
    //消费者线程启动，最终就是在EventProcessorInfo类中的start方法中启动的
    private final Collection<ConsumerInfo> consumerInfos = new ArrayList<>();


    //下面两个方法都是用来添加键值对到上面两个Map中的
    public void add(
            final EventProcessor eventprocessor,
            final EventHandler<? super T> handler,
            final SequenceBarrier barrier)
    {
        final EventProcessorInfo<T> consumerInfo = new EventProcessorInfo<>(eventprocessor, handler, barrier);
        eventProcessorInfoByEventHandler.put(handler, consumerInfo);
        eventProcessorInfoBySequence.put(eventprocessor.getSequence(), consumerInfo);
        consumerInfos.add(consumerInfo);
    }


    public void add(final EventProcessor processor)
    {
        final EventProcessorInfo<T> consumerInfo = new EventProcessorInfo<>(processor, null, null);
        eventProcessorInfoBySequence.put(processor.getSequence(), consumerInfo);
        consumerInfos.add(consumerInfo);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:这个方法是第二版本新添加的
     */
    public void add(final WorkerPool<T> workerPool, final SequenceBarrier sequenceBarrier)
    {   //把workerPool封装到WorkerPoolInfo中
        final WorkerPoolInfo<T> workerPoolInfo = new WorkerPoolInfo<>(workerPool, sequenceBarrier);
        //添加到集合中
        consumerInfos.add(workerPoolInfo);
        //遍历workerPool对象管理的每一个消费者的Sequence，而Sequence封装着每一个消费者的消费进度
        for (Sequence sequence : workerPool.getWorkerSequences())
        {   //在这里把消费进度和对应的消费者信息添加到Map中
            eventProcessorInfoBySequence.put(sequence, workerPoolInfo);
        }
    }

    //该方法就是用来获取消费进度最慢的那个消费者的消费进度
    public Sequence[] getLastSequenceInChain(boolean includeStopped)
    {
        List<Sequence> lastSequence = new ArrayList<>();
        for (ConsumerInfo consumerInfo : consumerInfos)
        {
            if ((includeStopped || consumerInfo.isRunning()) && consumerInfo.isEndOfChain())
            {   //现在大家知道了，在第一个版本中这里返回一个数组，是为什么了吧
                //其实是为了兼容workerPool对象的消费者进度，因为这个对象的消费者进度
                //返回的就是一个数组
                final Sequence[] sequences = consumerInfo.getSequences();
                Collections.addAll(lastSequence, sequences);
            }
        }
        return lastSequence.toArray(new Sequence[lastSequence.size()]);
    }


    //通过handler来获得对应的EventProcessor对象，因为handler会被包装到EventProcessor对象中
    public EventProcessor getEventProcessorFor(final EventHandler<T> handler)
    {
        final EventProcessorInfo<T> eventprocessorInfo = getEventProcessorInfo(handler);
        if (eventprocessorInfo == null)
        {
            throw new IllegalArgumentException("The event handler " + handler + " is not processing events.");
        }
        return eventprocessorInfo.getEventProcessor();
    }

    //通过handler来获得对应的消费者线程的消费进度
    public Sequence getSequenceFor(final EventHandler<T> handler)
    {
        return getEventProcessorFor(handler).getSequence();
    }


    //大家肯定还记的ConsumerInfo接口中的markAsUsedInBarrier方法，这里的这个方法
    //就是起到一个管理的作用，真正执行的仍然是每一个ConsumerInfo中的markAsUsedInBarrier方法
    public void unMarkEventProcessorsAsEndOfChain(final Sequence... barrierEventProcessors)
    {
        for (Sequence barrierEventProcessor : barrierEventProcessors)
        {
            getEventProcessorInfo(barrierEventProcessor).markAsUsedInBarrier();
        }
    }

    //迭代器方法
    @Override
    public Iterator<ConsumerInfo> iterator()
    {
        return consumerInfos.iterator();
    }


    //根据handler获得消费者的序号屏障，这里我想再强调一下，每一个消费者都有自己专属的序号屏障
    public SequenceBarrier getBarrierFor(final EventHandler<T> handler)
    {
        final ConsumerInfo consumerInfo = getEventProcessorInfo(handler);
        return consumerInfo != null ? consumerInfo.getBarrier() : null;
    }

    //通过handler获得消费者的EventProcessorInfo
    private EventProcessorInfo<T> getEventProcessorInfo(final EventHandler<T> handler)
    {
        return eventProcessorInfoByEventHandler.get(handler);
    }

    //根据消费者的消费进度获取对应的消费者
    //这里我仍然要强调一下，Sequence是每个消费者唯一的，存入到Map中，当然就能根据key获得对应的消费者
    private ConsumerInfo getEventProcessorInfo(final Sequence barrierEventProcessor)
    {
        return eventProcessorInfoBySequence.get(barrierEventProcessor);
    }
}
