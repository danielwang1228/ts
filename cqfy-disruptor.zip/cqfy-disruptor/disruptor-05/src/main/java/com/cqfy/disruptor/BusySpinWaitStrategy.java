package com.cqfy.disruptor;


import com.cqfy.disruptor.util.ThreadHints;


//这个阻塞策略中的线程不会阻塞，会一直自旋等待，线程多的话还是有些浪费资源的
public final class BusySpinWaitStrategy implements WaitStrategy
{
    @Override
    public long waitFor(
            final long sequence, Sequence cursor, final Sequence dependentSequence, final SequenceBarrier barrier)
            throws AlertException, InterruptedException
    {
        long availableSequence;
        while ((availableSequence = dependentSequence.get()) < sequence)
        {
            barrier.checkAlert();
            //这里也是阻塞，但是也是自旋等待
            ThreadHints.onSpinWait();
        }

        return availableSequence;
    }

    //因为线程是自旋等待，根本就没有阻塞，所以，也就不必被唤醒
    @Override
    public void signalAllWhenBlocking()
    {
    }
}