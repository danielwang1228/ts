package com.cqfy.disruptor.test;

import com.cqfy.disruptor.*;
import com.cqfy.disruptor.dsl.Disruptor;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import static com.cqfy.disruptor.dsl.ProducerType.SINGLE;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/27
 * @Description:这个是单生产者多消费者的测试类，是第二个版本新添加的测试类
 * 这个测试类测试的就是单个生产者发布数据，多个消费者共同消费这些消息，注意，这里是
 * 共同消费，比如发布了10条数据，那么现在有3个线程，就是3个线程共同消费这10条数据
 * 而不是每一个线程都消费十条了
 */
public class MultiConsumerTest {

    public static void main(String[] args) throws InterruptedException {

        SimpleEventFactory<String> eventFactory = new SimpleEventFactory<>();
        int ringBufferSize = 128;
        ThreadFactory threadFactory = Executors.defaultThreadFactory();
        WaitStrategy waitStrategy = new SleepingWaitStrategy();
        //创建disruptor，注意，这里使用的就是单生产者模式
        Disruptor<Event<String>> disruptor = new Disruptor<>(eventFactory, ringBufferSize, threadFactory, SINGLE, waitStrategy);
        //这里是相较于第一版本改动的地方，每一个workerHandler都相当于一个消费者线程
        //创建了两个线程，现在是这两个线程共同消费下面发布的10条生产者数据
        WorkHandler<Event<String>> eventHandler = new WorkerEventHandler();
        WorkHandler<Event<String>> eventHandler1 = new WorkerEventHandler();
        //把消费者设置到disruptor中，这里是第二版本该懂的地方，不在使用handleEventsWith方法了
        //而是使用handleEventsWithWorkerPool方法
        disruptor.handleEventsWithWorkerPool(eventHandler,eventHandler1);

        ExceptionHandler<Event<String>> exceptionHandler = new SimpleExceptionHandler<>();
        disruptor.setDefaultExceptionHandler(exceptionHandler);


        EventTranslatorOneArg<Event<String>, String> eventTranslatorOneArg =
                new EventTranslatorOneArg<Event<String>, String>() {
                    @Override
                    public void translateTo(Event<String> event, long sequence, String arg0) {
                        event.setData(arg0);
                    }
                };
        for (int i = 0; i < 10; i++) {
            disruptor.publishEvent(eventTranslatorOneArg, "第"+i+"条");
        }



        //这个的启动要在发布生产者消息之前
        disruptor.start();


        Thread.sleep(3000);
        disruptor.shutdown();
    }
}
