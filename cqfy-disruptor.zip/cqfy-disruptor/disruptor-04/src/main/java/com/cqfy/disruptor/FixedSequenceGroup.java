package com.cqfy.disruptor;

import com.cqfy.disruptor.util.Util;

import java.util.Arrays;


//该类的方法很简单，大家自己看看就行
public final class FixedSequenceGroup extends Sequence
{
    private final Sequence[] sequences;

    //构造方法
    public FixedSequenceGroup(Sequence[] sequences)
    {
        this.sequences = Arrays.copyOf(sequences, sequences.length);
    }

    //得到顺序消费中，先消费的消费者们的最慢的消费进度
    @Override
    public long get()
    {
        return Util.getMinimumSequence(sequences);
    }

    @Override
    public String toString()
    {
        return Arrays.toString(sequences);
    }


    @Override
    public void set(long value)
    {
        throw new UnsupportedOperationException();
    }


    @Override
    public boolean compareAndSet(long expectedValue, long newValue)
    {
        throw new UnsupportedOperationException();
    }


    @Override
    public long incrementAndGet()
    {
        throw new UnsupportedOperationException();
    }


    @Override
    public long addAndGet(long increment)
    {
        throw new UnsupportedOperationException();
    }
}
