package com.cqfy.disruptor.dsl;

import com.cqfy.disruptor.BatchEventProcessor;
import com.cqfy.disruptor.EventHandler;
import com.cqfy.disruptor.EventProcessor;
import com.cqfy.disruptor.ExceptionHandler;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/29
 * @Description:这个类的作用很简单，就是为用户定义的消费handler设置异常处理器
 */
public class ExceptionHandlerSetting<T>
{
    private final EventHandler<T> eventHandler;
    private final ConsumerRepository<T> consumerRepository;

    ExceptionHandlerSetting(
            final EventHandler<T> eventHandler,
            final ConsumerRepository<T> consumerRepository)
    {
        this.eventHandler = eventHandler;
        this.consumerRepository = consumerRepository;
    }


    @SuppressWarnings("unchecked")
    public void with(ExceptionHandler<? super T> exceptionHandler)
    {
        final EventProcessor eventProcessor = consumerRepository.getEventProcessorFor(eventHandler);
        if (eventProcessor instanceof BatchEventProcessor)
        {
            ((BatchEventProcessor<T>) eventProcessor).setExceptionHandler(exceptionHandler);
            consumerRepository.getBarrierFor(eventHandler).alert();
        }
        else
        {
            throw new RuntimeException(
                    "EventProcessor: " + eventProcessor + " is not a BatchEventProcessor " +
                            "and does not support exception handlers");
        }
    }
}
