package com.cqfy.disruptor.test;


import com.cqfy.disruptor.*;
import com.cqfy.disruptor.dsl.Disruptor;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import static com.cqfy.disruptor.dsl.ProducerType.MULTI;
import static com.cqfy.disruptor.dsl.ProducerType.SINGLE;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/28
 * @Description:该测试类是第三版本新添加的，就是测试多生产者功能的测试类
 */
public class MultiProducerTest {

    public static void main(String[] args) throws InterruptedException {

        SimpleEventFactory<String> eventFactory = new SimpleEventFactory<>();

        int ringBufferSize = 128;

        ThreadFactory threadFactory = Executors.defaultThreadFactory();

        WaitStrategy waitStrategy = new SleepingWaitStrategy();
        //创建disruptor，注意，这里使用的就是多生产者模式
        Disruptor<Event<String>> disruptor = new Disruptor<>(eventFactory, ringBufferSize, threadFactory, MULTI, waitStrategy);
        //创建消费者处理器，测试类中只创建一个吧
        EventHandler<Event<String>> eventHandler = new SimpleEventHandler<>();

        disruptor.handleEventsWith(eventHandler);

        ExceptionHandler<Event<String>> exceptionHandler = new SimpleExceptionHandler<>();

        disruptor.setDefaultExceptionHandler(exceptionHandler);

        disruptor.start();

        EventTranslatorOneArg<Event<String>, String> eventTranslatorOneArg =
                new EventTranslatorOneArg<Event<String>, String>() {
                    @Override
                    public void translateTo(Event<String> event, long sequence, String arg0) {
                        event.setData(arg0);
                    }
                };
        //注意，现在是多生产者，既然是多生产者，就弄两个线程来发布生产者数据吧
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    disruptor.publishEvent(eventTranslatorOneArg, "第"+i+"条");
                }
            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 10; i < 20; i++) {
                    disruptor.publishEvent(eventTranslatorOneArg, "第"+i+"条");
                }
            }
        }).start();

        //现在是异步发布生产者数据了，所以让主线程睡一会
        //如果继续向下执行的话，异步线程还没发布数据，程序就shutdown了
        Thread.sleep(3000);
        disruptor.shutdown();
    }
}
