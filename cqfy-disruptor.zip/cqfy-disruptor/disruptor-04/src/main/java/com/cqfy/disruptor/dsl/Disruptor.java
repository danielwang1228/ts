package com.cqfy.disruptor.dsl;

import com.cqfy.disruptor.*;
import com.cqfy.disruptor.util.Util;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/18
 * @Description:这个类是该框架的核心类之一，就相当于Netty的ServerBootStarp，虽然自己没有多么核心的逻辑要处理
 * 但是核心逻辑的启动方法都在该类中
 */
public class Disruptor<T>
{

    //鼎鼎大名的环形数组类
    private final RingBuffer<T> ringBuffer;
    //创建消费者线程的执行器，这里只是一个接口，其实创建的是它的实现类BasicExecutor对象
    private final Executor executor;
    //这个仓库中存储着每一个消费者，启动的时候其实就是从这个里面启动每一个消费者线程
    private final ConsumerRepository<T> consumerRepository = new ConsumerRepository<>();
    //Disruptor启动状态的标记，因为在整个程序中要确保Disruptor只启动一次，因为所有消费者线程都是被Disruptor
    //的start方法启动的，Disruptor只启动一次，其实是保证了所有的线程只启动一次
    //Disruptor究竟要翻译成什么比较好呢？其实我也没有一个特别好的意见
    private final AtomicBoolean started = new AtomicBoolean(false);
    //处理异常的handler
    private ExceptionHandler<? super T> exceptionHandler = new ExceptionHandlerWrapper<>();

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/18
     * @Description:构造方法，参数的具体作用写在下面的注释中了
     */
    public Disruptor(
            final EventFactory<T> eventFactory,
            final int ringBufferSize,
            final ThreadFactory threadFactory,
            final ProducerType producerType,
            final WaitStrategy waitStrategy)
    {
        this(
                //第一个参数为生产者类型，分单生产者模式和多生产者模式
                //第二个参数就是事件创建工厂，其实这每一个事件就是消费者要消费的东西，也就是消费者线程要执行的任务
                //第三个参数就是RingBuffer的容量
                //第四个参数就是等待策略
                //在这里创建真正存储数据的容器RingBuffer
                RingBuffer.create(producerType, eventFactory, ringBufferSize, waitStrategy),
                //创建线程工厂
                new BasicExecutor(threadFactory));
    }


    //在这里给Disruptor中的两个成员变量赋值
    private Disruptor(final RingBuffer<T> ringBuffer, final Executor executor)
    {
        //环形数组类赋值
        this.ringBuffer = ringBuffer;
        //创建消费者线程的执行器赋值
        this.executor = executor;
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/18
     * @Description:把用户定义的消费事件包装成一个个消费者runnable任务，这些任务就会交给线程来执行
     * 这个方法的参数是个可变参数，因为用户可能会定义多个消费者事件，也就是多个消费者
     */
    @SuppressWarnings("varargs")
    @SafeVarargs
    public final EventHandlerGroup<T> handleEventsWith(final EventHandler<? super T>... handlers)
    {
        //注意，下面方法的第一个参数为数组，这里默认使用的是空数组，这个数组的作用会在后面的版本讲到，现在先不解释了
        //这个方法就会把消费事件包装在事件处理器中，一个消费者对应着一个事件处理器，一个事件处理器最终会交给一个线程来执行
        return createEventProcessors(new Sequence[0], handlers);
    }



    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/18
     * @Description:这个方法和上面方法的区别就是，这个方法直接添加的是EventProcessor对象
     * 上面的那个方法添加的是EventHandler对象，实际上EventHandler对象也会被包装成EventProcessor对象的
     */
    public EventHandlerGroup<T> handleEventsWith(final EventProcessor... processors)
    {
        for (final EventProcessor processor : processors)
        {   //把EventProcessor对象添加到消费者仓库中
            consumerRepository.add(processor);
        }
        //创建一个存放消费者的消费进度的数组
        final Sequence[] sequences = new Sequence[processors.length];
        for (int i = 0; i < processors.length; i++)
        {   //得到每一个消费者的消费进度
            sequences[i] = processors[i].getSequence();
        }
        //把这些新添加进来的消费者的消费进度添加到消费者序列中
        //这个方法其实会调用到ringBuffer对象中，然后在ringBuffer对象中继续调用到
        //Sequencer这个序号生成器中，因为ringBuffer必须要知道消费者序列中最慢的那个消费进度
        //这样才能保证给生产者分配可使用的序号时，保证不会覆盖尚未被消费的数据
        ringBuffer.addGatingSequences(sequences);
        //把这些新添加进来的消费者放到一个事件处理器组中
        return new EventHandlerGroup<>(this, consumerRepository, Util.getSequencesFor(processors));
    }



    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:该方法就是第二版本重点讲解的方法，多线程共同消费数据就是通过这个方法实现的
     * 这算是个入口方法吧
     */
    @SafeVarargs
    @SuppressWarnings("varargs")
    public final EventHandlerGroup<T> handleEventsWithWorkerPool(final WorkHandler<T>... workHandlers)
    {
        return createWorkerPool(new Sequence[0], workHandlers);
    }


    //设置用户定义的异常处理器
    @SuppressWarnings("unchecked")
    public void setDefaultExceptionHandler(final ExceptionHandler<? super T> exceptionHandler)
    {
        checkNotStarted();
        //这里就是判断一下，是否已经设置过用户定义的异常处理器了，因为用户定义的异常处理器
        //会被包装成ExceptionHandlerWrapper使用，如果异常处理器已经是ExceptionHandlerWrapper类型了
        //说明已经设置过了
        if (!(this.exceptionHandler instanceof ExceptionHandlerWrapper))
        {
            throw new IllegalStateException("setDefaultExceptionHandler can not be used after handleExceptionsWith");
        }
        //这里就是真正设置异常处理器
        ((ExceptionHandlerWrapper<T>)this.exceptionHandler).switchTo(exceptionHandler);
    }


    //添加异常处理器，这里添加的处理器会直接赋值给exceptionHandler成员变量
    public void handleExceptionsWith(final ExceptionHandler<? super T> exceptionHandler)
    {
        this.exceptionHandler = exceptionHandler;
    }

    //为用户定义的handler设置异常处理器
    public ExceptionHandlerSetting<T> handleExceptionsFor(final EventHandler<T> eventHandler)
    {
        return new ExceptionHandlerSetting<>(eventHandler, consumerRepository);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/29
     * @Description:这是第四版本引入的顺序消费的方法，传入的handler就是消费顺序在前的handler，after在这些handler
     * 之后的handler，它们消费的进度必须在这些handler之后
     */
    @SafeVarargs
    @SuppressWarnings("varargs")
    public final EventHandlerGroup<T> after(final EventHandler<T>... handlers)
    {
        final Sequence[] sequences = new Sequence[handlers.length];
        for (int i = 0, handlersLength = handlers.length; i < handlersLength; i++)
        {
            sequences[i] = consumerRepository.getSequenceFor(handlers[i]);
        }

        return new EventHandlerGroup<>(this, consumerRepository, sequences);
    }


    public EventHandlerGroup<T> after(final EventProcessor... processors)
    {
        for (final EventProcessor processor : processors)
        {
            consumerRepository.add(processor);
        }

        return new EventHandlerGroup<>(this, consumerRepository, Util.getSequencesFor(processors));
    }



    //发布生产者，其实就是发布数据让消费者去消费
    //这里大家也要弄清楚EventTranslatorOneArg的作用，环形数组初始化好的那一刻，其实环形数组中每一个
    //位置的事件对象都创建好了，只要程序不退出，这些对象是不会被垃圾回收的，而EventTranslatorOneArg
    //对象就是把发布者发布的真正消息传递到环形数组的每一个事件对象中去
    public <A> void publishEvent(final EventTranslatorOneArg<T, A> eventTranslator, final A arg)
    {
        ringBuffer.publishEvent(eventTranslator, arg);
    }


    //启动程序的方法，也就是启动每一个消费者线程
    public RingBuffer<T> start()
    {
        checkOnlyStartedOnce();
        for (final ConsumerInfo consumerInfo : consumerRepository)
        {
            consumerInfo.start(executor);
        }

        return ringBuffer;
    }


    //终止每一个消费者线程，可以看到，在该方法内部仍然是循环每一个消费者
    //然后让每一个消费者自己去停止
    public void halt()
    {
        for (final ConsumerInfo consumerInfo : consumerRepository)
        {
            consumerInfo.halt();
        }
    }


    //终止程序的方法
    public void shutdown()
    {
        try
        {   //这个是真正终止程序的方法，这里面的第一个参数是-1，可见是没有超时时间的
            //会等到程序中所有的消费者消费完所有事件才会退出程序
            shutdown(-1, TimeUnit.MILLISECONDS);
        }
        catch (final TimeoutException e)
        {
            exceptionHandler.handleOnShutdownException(e);
        }
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/19
     * @Description:这个就是真正关闭程序的事件，第一个参数就是超时时间
     */
    public void shutdown(final long timeout, final TimeUnit timeUnit) throws TimeoutException
    {   //这里先计算出超时时间
        final long timeOutAt = System.currentTimeMillis() + timeUnit.toMillis(timeout);
        //这里会一直判断程序中的消费者是否消费完了所有的事件
        while (hasBacklog())
        {
            //如果超时了就抛出异常
            if (timeout >= 0 && System.currentTimeMillis() > timeOutAt)
            {
                throw TimeoutException.INSTANCE;
            }
        }
        //循环结束了就开始终止每一个运行的消费者线程
        halt();
    }

    //得到环形数组的方法
    public RingBuffer<T> getRingBuffer()
    {
        return ringBuffer;
    }

    //得到当前的生产者序号
    public long getCursor()
    {
        return ringBuffer.getCursor();
    }

    //获得环形数组存储数据的个数
    public long getBufferSize()
    {
        return ringBuffer.getBufferSize();
    }

    //根据序列号取出环形数组对应的生产者事件
    public T get(final long sequence)
    {
        return ringBuffer.get(sequence);
    }

    //根据handler获得消费者的序号屏障
    public SequenceBarrier getBarrierFor(final EventHandler<T> handler)
    {
        return consumerRepository.getBarrierFor(handler);
    }

    //通过handler来获得对应的消费者线程的消费进度
    public long getSequenceValueFor(final EventHandler<T> b1)
    {
        return consumerRepository.getSequenceFor(b1).get();
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/19
     * @Description:这个方法也有必要讲一讲，就是用来判断当前的程序中是否还有未被消费者消费的事件
     * 实际上，不管有多少个生产者在发布事件，最终事件只会放到环形数组中，消费者从环形数组中消费事件
     * 消费者可能有多个，每个消费者消费的进度可能并不一致，有可能程序结束的时候，还有消费者未消费完
     * 所有的事件，这个方法就是用来判断是否都消费完了
     */
    private boolean hasBacklog()
    {   //得到最新的生产者的序号
        final long cursor = ringBuffer.getCursor();
        //遍历每一个消费者
        for (final Sequence consumer : consumerRepository.getLastSequenceInChain(false))
        {
            //判断每一个消费者的消费序号是否小于最新的生产者的序号
            if (cursor > consumer.get())
            {
                //如果有一个小于，则说明还没有消费完，所以返回true，
                return true;
            }
        }
        return false;
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/19
     * @Description:该方法会把用户定义的消费者handler包装到EventProcessor对象中，是这个类中最重要的一个方法
     */
    EventHandlerGroup<T> createEventProcessors(
            final Sequence[] barrierSequences,
            final EventHandler<? super T>[] eventHandlers)
    {
        //检查Disruptor是否启动过，因为要保证Disruptor只能启动一次
        //创建EventProcessor对象的动作肯定要在Disruptor启动之前，所以这里必须检查一下
        checkNotStarted();
        //定义一个Sequence数组，Sequence其实就是消费者的消费进度，也可以说是消费者的消费序号
        //这个数组的长度就是用户定义的eventHandlers的长度
        final Sequence[] processorSequences = new Sequence[eventHandlers.length];
        //创建消费者的序号屏障，这个方法在第一版本还无法讲解得十分全面，本身序号屏障的工作就是协调生产者和消费者
        //的进度关系，消费者不能走到生产者前面。但是在下面的这个方法中，有一个barrierSequences参数，这个参数
        //是一个数组，这个数组的作用要在后面的版本才能讲解，这里只简单解释一下，比如说，现在有一些消费者
        //这些消费者要在另一些消费者消费完了某条消息后，才能消费这条消息，这种消费的顺序关系也是由
        //消费屏障来处理的
        final SequenceBarrier barrier = ringBuffer.newBarrier(barrierSequences);
        //把用户定义的每一个eventHandlers包装成BatchEventProcessor对象
        for (int i = 0, eventHandlersLength = eventHandlers.length; i < eventHandlersLength; i++)
        {
            final EventHandler<? super T> eventHandler = eventHandlers[i];
            //创建BatchEventProcessor对象，每一个BatchEventProcessor对象都是一个消费者
            //BatchEventProcessor实现了EventProcessor接口，而EventProcessor接口继承了runnable接口
            //所以每一个EventProcessor对象就是一个Runnable任务，会交给每一个线程来执行
            //所以，每一个EventProcessor就对应一个线程，并且大家可以看到，每一个BatchEventProcessor
            //对象中都持有环形数组，序号屏障，还有eventHandler本身
            //注意，在创建好batchEventProcessor对象的时候，消费者的序号就已经初始化好了
            final BatchEventProcessor<T> batchEventProcessor =
                    new BatchEventProcessor<>(ringBuffer, barrier, eventHandler);
            //判断异常处理器是否为空
            if (exceptionHandler != null)
            {   //不为空则设置异常处理器
                batchEventProcessor.setExceptionHandler(exceptionHandler);
            }
            //把创建好的batchEventProcessor对象添加到消费者仓库中
            consumerRepository.add(batchEventProcessor, eventHandler, barrier);
            //这时候每一个消费者的消费序号已经初始化好了，直接可以从batchEventProcessor对象中得到
            //然后就可以放到最上面定义的数组中了
            processorSequences[i] = batchEventProcessor.getSequence();
        }
        //因为添加了新的消费者了，所以最慢消费者应该更新一下，新添加的消费者的消费进度肯定是最慢的
        //这里传进去了两个参数，有必要解释一下这两个参数
        //第二个参数很明显了，就是新添加进来的消费者的消费序号的数组，有了这些新添加进来的消费者的消费序号，才能知道现在
        //哪些消费者应该是消费进度比较慢的消费者
        //而第一个参数就是我之前跟大家简单解释了一下的数组，这里可以举一个简单的例子，比如说新添加进来5个消费者
        //这5个消费者必须要在另外3个消费者消费完事件之后，才能消费事件，以前那3个消费者可能是消费比较慢的
        //现在有了这个顺序消费的关系，新添加的5个消费者变成了消费最慢的消费者。这里传进去的第1个参数对应的
        //就是3个消费者，有了新的消费者添加进来了，这3个消费者就不再是最慢的消费者了，需要把它们的最慢进度删除
        updateGatingSequencesForNextInChain(barrierSequences, processorSequences);
        //EventHandlerGroup在第一版本还用不到，所以暂且先不讲解了，只要程序先不报错就行
        //其实也可以简单说一下，其实就是把这次添加进来的所有消费者handler当作一组了，所以自然要封装带一个group中
        //并且正是因为把这一批消费handler当作一组了，所以它们才可以使用同一个序号屏障呀，其实这个序号屏障叫序列屏障
        //或者消费者顺序屏障更好，大家理解意思就行了
        return new EventHandlerGroup<>(this, consumerRepository, processorSequences);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/19
     * @Description:这个方法就是更新最慢消费者序列的方法，该方法会在上面的方法中被调用，并且传进去两个参数
     */
    private void updateGatingSequencesForNextInChain(final Sequence[] barrierSequences, final Sequence[] processorSequences)
    {
        if (processorSequences.length > 0)
        {
            //把新添加的消费者的消费者进度，也就是消费序号全都添加到gatingSequences这个数组中
            //gatingSequences这个数组是AbstractSequencer类的成员变量
            //该数组中存储的就是每个消费者线程消费的进度，通过这个数组就可以找到消费最慢的线程的消费进度
            //这样给生产者分配序号的时候，把要分配的序号和每一个消费者的消费进度做对比
            //只要有比生产者序号小的，就不能分配生产者序号，这样才不至于将尚未被消费的数据覆盖
            ringBuffer.addGatingSequences(processorSequences);
            //这里就是常规逻辑了，因为这些消费者成为了新添加的消费者的前置消费者，就可以不用观察这些消费者的消费进度了
            //只用观察最后消费的消费者进度即可，为什么这么说，比如说最后的消费者的消费进度是5，这就意味着前面的消费者肯定已经
            //把环形数组5号位置的数据消费了，所以，只用看最后的消费者即可
            for (final Sequence barrierSequence : barrierSequences)
            {
                ringBuffer.removeGatingSequence(barrierSequence);
            }
            //把这些消费者的最慢消费者身份更改掉，表示它不是最慢消费者了
            //说实话，这个框架中很多类名和方法名很难翻译，精通这个框架的人知道每个方法的作用是什么
            //但未必能讲清楚，大家还是要从文章中仔细品味，代码的注释只是起到一个辅助作用
            consumerRepository.unMarkEventProcessorsAsEndOfChain(barrierSequences);
        }
    }

    //这个方法在第一版本中用不上，所以就不讲了，大家不必在意这个方法
    EventHandlerGroup<T> createEventProcessors(
            final Sequence[] barrierSequences, final EventProcessorFactory<T>[] processorFactories)
    {
        final EventProcessor[] eventProcessors = new EventProcessor[processorFactories.length];
        for (int i = 0; i < processorFactories.length; i++)
        {
            eventProcessors[i] = processorFactories[i].createEventProcessor(ringBuffer, barrierSequences);
        }
        return handleEventsWith(eventProcessors);
    }



    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:创建WorkerPool的方法，一个WorkerPool中管理着多个WorkHandler，也就是消费者handler
     * 这个WorkHandler是用户自己定义的，定义几个，那么就会有几个线程共同消耗生产者发布的数据
     */
    EventHandlerGroup<T> createWorkerPool(
            final Sequence[] barrierSequences, final WorkHandler<? super T>[] workHandlers)
    {
        //在这一版本中默认barrierSequences仍然是空数组
        //创建序号屏障
        final SequenceBarrier sequenceBarrier = ringBuffer.newBarrier(barrierSequences);
        //创建workerPool对象，该对象中管理着用户定义的多个workerhandler
        final WorkerPool<T> workerPool = new WorkerPool<>(ringBuffer, sequenceBarrier, exceptionHandler, workHandlers);
        //把消费者的信息添加到消费者仓库中
        consumerRepository.add(workerPool, sequenceBarrier);
        //得到workerPool中所有消费者线程的消费进度
        final Sequence[] workerSequences = workerPool.getWorkerSequences();
        //把消费者进度添加到gatingSequences数组中，这个数组的作用在第一版中讲过了
        updateGatingSequencesForNextInChain(barrierSequences, workerSequences);
        //返回消费者处理器组，这个对象会越来越重要，后面的版本就会用到
        return new EventHandlerGroup<>(this, consumerRepository, workerSequences);
    }



    //检查程序是否启动了，如果已经启动就抛出异常
    private void checkNotStarted()
    {
        if (started.get())
        {
            throw new IllegalStateException("All event handlers must be added before calling starts.");
        }
    }

    //确保程序只启动一次
    private void checkOnlyStartedOnce()
    {
        if (!started.compareAndSet(false, true))
        {
            throw new IllegalStateException("Disruptor.start() must only be called once.");
        }
    }

    @Override
    public String toString()
    {
        return "Disruptor{" +
                "ringBuffer=" + ringBuffer +
                ", started=" + started +
                ", executor=" + executor +
                '}';
    }
}
