package com.cqfy.disruptor.test;

import com.cqfy.disruptor.EventHandler;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/8
 * @Description:这个就是消费者处理器，实际上就是消费者要干的事。这个处理器在程序内部会被包装成BatchEventProcessor对象
 * 这个对象才会被交给一个线程来执行。如果创建了多个SimpleEventHandler，就意味着会有多个BatchEventProcessor对象
 * 也就意味着会有多个消费者来消费事件，而消费的具体逻辑，就可以定义在下面的onEvent方法中，是由用户自己定义的
 */
public class SimpleEventHandler<T> implements EventHandler<Event<T>> {

    public int index;

    @Override
    public void onEvent(Event<T> event, long sequence, boolean endOfBatch) throws Exception {
        //这里，我就只打印一句话了
        System.out.println("消费者线程"+Thread.currentThread().getName()+"第"+index+"个处理器"+"已经消费了"+event.getData()+"数据了！");
    }
}
