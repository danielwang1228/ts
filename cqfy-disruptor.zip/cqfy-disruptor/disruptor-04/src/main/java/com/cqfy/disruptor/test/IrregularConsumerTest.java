package com.cqfy.disruptor.test;


import com.cqfy.disruptor.*;
import com.cqfy.disruptor.dsl.Disruptor;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import static com.cqfy.disruptor.dsl.ProducerType.SINGLE;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/29
 * @Description:不规则消费者测试类，这个类就是第四版本新添加的
 */
public class IrregularConsumerTest {

    public static void main(String[] args) {

        SimpleEventFactory<String> eventFactory = new SimpleEventFactory<>();
        int ringBufferSize = 128;
        ThreadFactory threadFactory = Executors.defaultThreadFactory();
        WaitStrategy waitStrategy = new SleepingWaitStrategy();
        //创建disruptor，这里使用的就是单生产者模式
        Disruptor<Event<String>> disruptor = new Disruptor<>(eventFactory, ringBufferSize, threadFactory, SINGLE, waitStrategy);
        //创建多个消费者
        EventHandler[] eventHandlers = new EventHandler[5];
        for (int i = 0; i < eventHandlers.length; i++) {
            eventHandlers[i] = new SimpleEventHandler<>();
            SimpleEventHandler handler = (SimpleEventHandler)eventHandlers[i];
            handler.index = i;
        }

        //1，首先按照4-1的消费顺序，就是前4个handler并行消费，最后一个在它们之后消费
        //测试这个例子，会发现不管怎么测试，都是第2个处理器最后消费消息
        //disruptor.handleEventsWith(eventHandlers[0],eventHandlers[1]).then(eventHandlers[2]);



        //2，把消费者设置到disruptor中，按照eventHandler0独自消费，eventHandler1和eventHandler2并行消费，但是在eventHandler0
        //之后消费的顺序，最后是eventHandler3，eventHandler4并行消费，但是在eventHandler1和eventHandler2之后
        //不管怎么测试消费顺序总是 0 12/21 34/43
        //其他的调用方式大家自己开发吧，我就不搞了，知识都已经讲明白了
        disruptor.handleEventsWith(eventHandlers[0]).then(eventHandlers[1],eventHandlers[2])
                .then(eventHandlers[3],eventHandlers[4]);






        ExceptionHandler<Event<String>> exceptionHandler = new SimpleExceptionHandler<>();
        disruptor.setDefaultExceptionHandler(exceptionHandler);
        //这个的启动要在发布生产者消息之前
        disruptor.start();

        EventTranslatorOneArg<Event<String>, String> eventTranslatorOneArg =
                new EventTranslatorOneArg<Event<String>, String>() {
                    @Override
                    public void translateTo(Event<String> event, long sequence, String arg0) {
                        event.setData(arg0);
                    }
                };

        //为了看的清楚，就发布一条数据
        for (int i = 0; i < 1; i++) {
            disruptor.publishEvent(eventTranslatorOneArg, "第"+i+"条");
        }

        disruptor.shutdown();
    }
}
