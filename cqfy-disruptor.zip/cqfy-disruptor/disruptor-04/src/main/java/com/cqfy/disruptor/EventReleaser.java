package com.cqfy.disruptor;



public interface EventReleaser
{
    void release();
}
