package com.cqfy.disruptor;




public interface EventReleaseAware
{
    void setEventReleaser(EventReleaser eventReleaser);
}