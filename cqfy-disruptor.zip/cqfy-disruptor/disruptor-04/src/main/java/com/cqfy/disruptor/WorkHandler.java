package com.cqfy.disruptor;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/27
 * @Description:消费者要实现的接口，消费者的逻辑就定义在该类的方法中
 */
public interface WorkHandler<T>
{

    void onEvent(T event) throws Exception;
}