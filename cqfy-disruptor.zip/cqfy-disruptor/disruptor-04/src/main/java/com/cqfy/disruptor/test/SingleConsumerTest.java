package com.cqfy.disruptor.test;

import com.cqfy.disruptor.*;
import com.cqfy.disruptor.dsl.Disruptor;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import static com.cqfy.disruptor.dsl.ProducerType.SINGLE;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/8
 * @Description:单消费者单生产者的测试例子
 */
public class SingleConsumerTest {


    public static void main(String[] args) {
        //首先把事件工厂创建出来，这里可以看出泛型是String
        //这也就意味着Event中的data就是String
        SimpleEventFactory<String> eventFactory = new SimpleEventFactory<>();
        //设置环形数组的长度，其实就是RingBuffer中数组的容量。注意，这个环形数组的长度必须是2的n次幂
        int ringBufferSize = 128;
        //创建线程工厂，这个线程工厂是专门创建消费者线程的
        ThreadFactory threadFactory = Executors.defaultThreadFactory();
        //设置等待策略
        WaitStrategy waitStrategy = new SleepingWaitStrategy();
        //创建disruptor，注意，这里使用的就是单生产者模式
        Disruptor<Event<String>> disruptor = new Disruptor<>(eventFactory, ringBufferSize, threadFactory, SINGLE, waitStrategy);
        //创建消费者处理器，因为是单消费者模式，所以只创建一个消费者处理器即可
        EventHandler<Event<String>> eventHandler = new SimpleEventHandler<>();
        //把消费者设置到disruptor中，然后被包装成一个BatchEventProcessor对象
        disruptor.handleEventsWith(eventHandler);
        //创建用户自己定义的异常处理器
        ExceptionHandler<Event<String>> exceptionHandler = new SimpleExceptionHandler<>();
        //把异常处理器设置到程序内部，替换程序内部默认的异常处理器
        disruptor.setDefaultExceptionHandler(exceptionHandler);
        //现在就可以启动程序了，注意，启动程序，其实就是启动的消费者线程，但是现在很明显还没有数据被放到环形数组中
        //消费者是没有数据可以消费的，所以就会根据等待策略等待生产者的数据到来
        disruptor.start();
        //下面这个是一个事件转换器，就是把用户定义的字符串给Event对象的data属性赋值，这样，Event对象就终于完整了
        //在程序内部，Event对象一旦创建出来就不会销毁了，只要程序不终止就会一直存在，而真正要被消费的数据，是
        //Event对象中的data字符串，字符串会当作生产者生产的数据放进程序内部，也就是放到Event对象中
        EventTranslatorOneArg<Event<String>, String> eventTranslatorOneArg =
                new EventTranslatorOneArg<Event<String>, String>() {
                    @Override
                    public void translateTo(Event<String> event, long sequence, String arg0) {
                        event.setData(arg0);
                    }
                };
        //发布十条数据，生产者一旦发布了数据，消费者就会直接去获取数据然后消费了
        for (int i = 0; i < 10; i++) {
            disruptor.publishEvent(eventTranslatorOneArg, "第"+i+"条");
        }
        //终止程序
        disruptor.shutdown();
    }
}

