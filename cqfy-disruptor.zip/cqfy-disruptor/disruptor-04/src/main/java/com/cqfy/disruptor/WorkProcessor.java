package com.cqfy.disruptor;

import java.util.concurrent.atomic.AtomicBoolean;



/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/27
 * @Description:这个类就是用来包装用户定义的每一个消费handler的，就叫工作处理器吧
 */
public final class WorkProcessor<T>
        implements EventProcessor
{
    //判断该工作处理器是否正在运行
    private final AtomicBoolean running = new AtomicBoolean(false);
    //消费者自身的消费进度
    private final Sequence sequence = new Sequence(Sequencer.INITIAL_CURSOR_VALUE);
    //环形数组
    private final RingBuffer<T> ringBuffer;
    //序号屏障
    private final SequenceBarrier sequenceBarrier;
    //用户定义的消费者处理器，是真正执行消费者逻辑的处理器
    private final WorkHandler<? super T> workHandler;
    //异常处理器
    private final ExceptionHandler<? super T> exceptionHandler;
    //WorkerPool自身的消费进度
    private final Sequence workSequence;
    //在第二版本代码中这个用不到，所以就先不讲了
    private final EventReleaser eventReleaser = new EventReleaser()
    {
        @Override
        public void release()
        {
            sequence.set(Long.MAX_VALUE);
        }
    };
    //超时处理器
    private final TimeoutHandler timeoutHandler;

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:构造方法，里面就是一些简单的赋值，也不再讲解了
     */
    public WorkProcessor(
            final RingBuffer<T> ringBuffer,
            final SequenceBarrier sequenceBarrier,
            final WorkHandler<? super T> workHandler,
            final ExceptionHandler<? super T> exceptionHandler,
            final Sequence workSequence)
    {
        this.ringBuffer = ringBuffer;
        this.sequenceBarrier = sequenceBarrier;
        this.workHandler = workHandler;
        this.exceptionHandler = exceptionHandler;
        this.workSequence = workSequence;

        if (this.workHandler instanceof EventReleaseAware)
        {
            ((EventReleaseAware) this.workHandler).setEventReleaser(eventReleaser);
        }

        timeoutHandler = (workHandler instanceof TimeoutHandler) ? (TimeoutHandler) workHandler : null;
    }

    //返回消费进度
    @Override
    public Sequence getSequence()
    {
        return sequence;
    }

    //终止处理器工作
    @Override
    public void halt()
    {
        running.set(false);
        sequenceBarrier.alert();
    }

    //判断处理器是否在运行
    @Override
    public boolean isRunning()
    {
        return running.get();
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:可以说是第二版本代码中要讲解的最重要的方法了，其他新添加的内容都有第一版本的影子
     * 这个也不例外，但是这个的核心肯定和第一版本不同
     */
    @Override
    public void run()
    {
        //把启动标志置为true
        if (!running.compareAndSet(false, true))
        {
            throw new IllegalStateException("Thread is already running");
        }
        //把终止信号置为false
        sequenceBarrier.clearAlert();
        //执行LifecycleAware接口方法的回调
        notifyStart();
        //这个默认为true，多个线程竞争下一个可消费序号时会用它来做判断
        boolean processedSequence = true;
        //这是一个判断值，最小的long整数，Long.MIN_VALUE只在循环的第一次使用，后面cachedAvailableSequence
        //就会被其他值赋值了
        long cachedAvailableSequence = Long.MIN_VALUE;
        //得到消费者当前的消费进度，如果是程序刚启动，这时候消费进度肯定是-1
        //只有消费了生产者后，才能更新自己的消费进度，而消费者启动是在生产者发布数据之前的
        //所以这时候消费者的进度还是初始值-1
        long nextSequence = sequence.get();
        //环形数组中存储的事件对象
        T event = null;
        //进入循环
        //在进入这个循环之后，我把注释分成了两部分，代表着两次循环的逻辑，当第一次循环的时候，大家可以看每行代码上
        //序号为1的注释，第二轮循环的时候，就看每行代码上序号为2的注释，两圈看下来，这个核心逻辑就明白了
        while (true)
        {
            try
            {   //1.先判断是否可以去竞争下一个序号了，默认为true
                //2.这时候，processedSequence已经是false，不会进入下面的这个分支，因为刚才已经给这个
                //2.消费者线程分配了，就是nextSequence，也就是序号0，但是当前消费者显然没有消费成功
                //2.所以不能进入下面这个分支同其它线程争抢下一个消费序号
                if (processedSequence)
                {   //1.但是一旦进入这个分支后，就会置为false
                    processedSequence = false;
                    do
                    {   //1.在这个小的循环中，得到下一个要分配的消费进度序号，这里还是通过举例为大家讲解
                        //1.如果是消费者刚启动的时候，workSequence中value的值肯定为-1，那么这里得到的
                        //1.nextSequence就为0
                        nextSequence = workSequence.get() + 1L;
                        //1.给当前争抢消费进度序号的消费进度赋值-1，注意啊，这里我们的各个数值都是针对消费者
                        //1.刚启动，而生产者还未发布生产数据的时候，这个时候条理最清楚
                        sequence.set(nextSequence - 1L);
                    }//1.CAS赋值，如果是当前消费者线程修改成功，那么就会把上面得到的nextSequence赋值给workSequence
                     //1.这时候workSequence的值就变成了0
                    while (!workSequence.compareAndSet(nextSequence - 1L, nextSequence));
                }
                //1.接下来就会判断之前得到cachedAvailableSequence是否大于nextSequence，注意，这时候nextSequence为0
                //1.消费者刚启动的时候，肯定是小于的，因为Long.MIN_VALUE是个负数，所以不会走下面的分支
                //2.第二次循环的时候，就会进入到这个分支中，因为现在cachedAvailableSequence已经被赋值成可消费的最大进度序号了
                if (cachedAvailableSequence >= nextSequence)
                {   //2.取出0号位的对象
                    event = ringBuffer.get(nextSequence);
                    //2.执行真正的消费逻辑
                    workHandler.onEvent(event);
                    //2.把该值设置为true，这样当前线程就可以在下一次循环时同其它线程争抢消费序号了
                    //2.到此为止，一个线程争抢序号以及执行消费逻辑的过程，我就已经为大家分析完了
                    processedSequence = true;
                }
                else
                {   //1.会走到这个分支，为什么走到这个分支呢？答案已经很明显了，因为是消费者刚启动，生产者还未发布生产数据
                    //1.自然没数据可消费，所以会在这里等待生产者发布生产数据，并返回可消费的最大的进度序号
                    //1.sequenceBarrier.waitFor(nextSequence)的逻辑和上个版本的一样，就不再讲解了
                    //1.接下来，就该进入第二轮循环了
                    cachedAvailableSequence = sequenceBarrier.waitFor(nextSequence);
                }
            }
            catch (final TimeoutException e)
            {
                notifyTimeout(sequence.get());
            }
            catch (final AlertException ex)
            {
                if (!running.get())
                {
                    break;
                }
            }
            catch (final Throwable ex)
            {
                //处理异常
                exceptionHandler.handleEventException(ex, nextSequence, event);
                //置为true，方便进入下一次循环争抢可消费序号
                processedSequence = true;
            }
        }
        //走到这里说明退出循环了，也就意味着消费者处理器要停止工作了
        notifyShutdown();
        running.set(false);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/27
     * @Description:下面这几个方法就不讲了，都是执行扩展接口中的方法
     */
    private void notifyTimeout(final long availableSequence)
    {
        try
        {
            if (timeoutHandler != null)
            {
                timeoutHandler.onTimeout(availableSequence);
            }
        }
        catch (Throwable e)
        {
            exceptionHandler.handleEventException(e, availableSequence, null);
        }
    }

    private void notifyStart()
    {
        if (workHandler instanceof LifecycleAware)
        {
            try
            {
                ((LifecycleAware) workHandler).onStart();
            }
            catch (final Throwable ex)
            {
                exceptionHandler.handleOnStartException(ex);
            }
        }
    }

    private void notifyShutdown()
    {
        if (workHandler instanceof LifecycleAware)
        {
            try
            {
                ((LifecycleAware) workHandler).onShutdown();
            }
            catch (final Throwable ex)
            {
                exceptionHandler.handleOnShutdownException(ex);
            }
        }
    }
}
