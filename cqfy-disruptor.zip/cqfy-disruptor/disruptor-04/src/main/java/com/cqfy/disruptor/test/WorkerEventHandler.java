package com.cqfy.disruptor.test;

import com.cqfy.disruptor.WorkHandler;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/27
 * @Description:多线程共同消费数据的handler，每一个handler都是一个消费者
 */
public class WorkerEventHandler<T> implements WorkHandler<Event<T>> {

    @Override
    public void onEvent(Event<T> event) throws Exception {
        //这里，我就只打印一句话了
        System.out.println("消费者线程"+Thread.currentThread().getName()+"已经消费了"+event.getData()+"数据了！");
    }
}
