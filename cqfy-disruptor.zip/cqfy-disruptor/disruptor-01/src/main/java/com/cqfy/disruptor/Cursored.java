package com.cqfy.disruptor;

public interface Cursored
{
    //获得当前生产者的序号
    long getCursor();
}