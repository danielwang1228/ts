package com.cqfy.disruptor.test;

import org.openjdk.jol.info.ClassLayout;

public class ObjectTestOne
{   //在父类填充空字节
    protected long p1, p2, p3, p4, p5, p6, p7;
}

class ValueTest extends ObjectTestOne
{
    //value前后都有7个空的long整数，也就是56个空白字节，加上当前的value正好是64个字节
    //高速缓存一行缓存64个字节，这样不管怎么读取这个value，它都会自己独占一个缓存行，不会出现伪共享了
    protected volatile long value;
}

class PaddingTest extends ValueTest
{   //在子类填充空字节
    protected long p9, p10, p11, p12, p13, p14, p15;

    public static void main(String[] args) {
        //System.out.println(RamUsageEstimator.sizeOf(new ObjectTest()));



        //Jbject a = new Jbject();
        //System.out.println(ClassLayout.parseInstance(a).toPrintable());

        PaddingTest b = new PaddingTest();
        System.out.println(ClassLayout.parseInstance(b).toPrintable());



        //SizeOf sizeOf = SizeOf.newInstance();
        //System.out.println(sizeOf.sizeOf(new Jbject()));
    }
}
