package com.cqfy.disruptor;


//事件工厂，专门创建包装生产者的事件对象的
public interface EventFactory<T>
{
    T newInstance();
}