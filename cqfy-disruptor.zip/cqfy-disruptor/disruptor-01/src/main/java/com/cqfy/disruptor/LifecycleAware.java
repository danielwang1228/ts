package com.cqfy.disruptor;


//消费处理器的生命周期接口
public interface LifecycleAware
{

    void onStart();


    void onShutdown();
}