package com.cqfy.disruptor;

import com.cqfy.disruptor.dsl.ProducerType;
import com.cqfy.disruptor.util.Util;
import sun.misc.Unsafe;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/23
 * @Description:环形数组的实现类，在该类中，用不到的方法都注释了，虽然这个类看着内容很多，其实在第一版本中内容很少
 */
abstract class RingBufferPad
{   //解决伪共享填充的字节
    protected long p1, p2, p3, p4, p5, p6, p7;
}

abstract class RingBufferFields<E> extends RingBufferPad
{
    //要在数组自身中填充的空数据的个数
    private static final int BUFFER_PAD;
    //对于数组这个对象来说，其内存布局分为数组对象头和有效数据部分，所谓有效数据就是数组真正存储的那部分数据
    //下面这个属性就是数组存储的第一个有效数据，在数组这个对象中的内存偏移量
    private static final long REF_ARRAY_BASE;
    //这个属性是用来计算数组中应该填充的空白字节大小的，会被2赋值
    private static final int REF_ELEMENT_SHIFT;
    //用Unsafe类的对象操纵数组
    private static final Unsafe UNSAFE = Util.getUnsafe();

    static
    {   //计算出数组每个位置的字节大小，一般都是4个字节
        final int scale = UNSAFE.arrayIndexScale(Object[].class);
        if (4 == scale)
        {
            REF_ELEMENT_SHIFT = 2;
        }
        else if (8 == scale)
        {
            REF_ELEMENT_SHIFT = 3;
        }
        else
        {
            throw new IllegalStateException("Unknown pointer size");
        }
        //这里得到的是32，说明要填充的空数据的个数是32个
        BUFFER_PAD = 128 / scale;
        //UFFER_PAD << REF_ELEMENT_SHIFT这行代码的意思就是填充32个空数据，每个数据是4字节，所以左移2位，就是乘以4，得到的就是128
        //也就是填充的这些数据一共是128个字节，而UNSAFE.arrayBaseOffset(Object[].class)得到的是数组中有效的首元素
        //在数组中的偏移量，首元素的地址加上要填充的字节数，得到的就是首元素相对于数组对象的最终偏移量
        //注意，这里的32个空数据都是要填充到数组头部的，也就是有效首元素的前面，所以才能这样计算首元素的偏移量
        REF_ARRAY_BASE = UNSAFE.arrayBaseOffset(Object[].class) + (BUFFER_PAD << REF_ELEMENT_SHIFT);
    }
    //用来进行位运算求取数组索引的掩码
    private final long indexMask;
    //存放数据的数组，可以抽象成环形数组
    private final Object[] entries;
    //环形数组的容量，必须是2的n次幂
    protected final int bufferSize;
    //序号生成器，用来给生产者分配可用序号的
    protected final Sequencer sequencer;

    //构造方法
    RingBufferFields(
            EventFactory<E> eventFactory,
            Sequencer sequencer)
    {
        this.sequencer = sequencer;
        this.bufferSize = sequencer.getBufferSize();

        if (bufferSize < 1)
        {
            throw new IllegalArgumentException("bufferSize must not be less than 1");
        }
        if (Integer.bitCount(bufferSize) != 1)
        {
            throw new IllegalArgumentException("bufferSize must be a power of 2");
        }

        //给掩码赋值
        this.indexMask = bufferSize - 1;
        //下面这行代码很重要，可以看见，数组的容量并不真的是bufferSize，而是在bufferSize的基础上
        //加上了64，这意味着bufferSize是真正有效数据的容量，而添加的64都是空数据，在有效数据之前填充32个空数据
        //在有效数据之后再填充32个空数据，这样就可以彻底保证数组的有效数据不会被其他属性伪共享了
        this.entries = new Object[sequencer.getBufferSize() + 2 * BUFFER_PAD];
        //初始化数组，创建数组中的对象，这个对象可以一直复用，在一定程度上减少垃圾回收
        //但是该对象中封装的对象，仍然会被垃圾回收，这个要搞清楚
        fill(eventFactory);
    }

    //在该方法中初始化数组，创建了数组中的每一个对象
    private void fill(EventFactory<E> eventFactory)
    {   //还是根据有效容量循环的
        for (int i = 0; i < bufferSize; i++)
        {
            //在这里数组的首位数据的索引就是BUFFER_PAD + i
            //因为BUFFER_PAD是填充的空数据的个数，所以要跳过这些空数据，然后进行真正的对象的创建
            //这里我还要多说一句，这种方式创建数组中的对象，可以让这些对象在堆内存中的地址尽可能的连续一点
            //现在数组中存放的只是对象的引用，这个要记住，但同一时间创建很多同类型对象，这些对象的内存地址很可能是连续的
            entries[BUFFER_PAD + i] = eventFactory.newInstance();
        }
    }

    //该方法也很重要，就是根据序号得到数组相应位置的数据
    @SuppressWarnings("unchecked")
    protected final E elementAt(long sequence)
    {   //sequence & indexMask计算的是要获取的有效数据原本的下标索引，下标计算出来了之后，乘以每个索引的大小，也就是4字节得到的就是下标
        //位置的数据在数组中的偏移量，这个偏移量再加上之前计算出来的第一个有效数据在数组中的偏移量，得到的就是要查询的真正数据在数组中的
        //偏移量，然后通过Unsafe获得就行了
        //  ==  这里的偏移量要单独计算     ====          ====           ====         .......
        //数组对象头   第一个有效数据   第二个有效数据   第三个有效数据
        return (E) UNSAFE.getObject(entries, REF_ARRAY_BASE + ((sequence & indexMask) << REF_ELEMENT_SHIFT));
    }
}

//环形数组类
public final class RingBuffer<E> extends RingBufferFields<E> implements Cursored, EventSequencer<E>, EventSink<E>
{
    public static final long INITIAL_CURSOR_VALUE = Sequence.INITIAL_VALUE;
    //填充字节，解决伪共享。这个字节和最开始父类填充的字节是为了不让中间的类，也就是定义了数组的那个类中的属性被其他类伪共享
    //要理解这一点，还得掌握Java对象在内存中的布局，以及怎么被读取到高速缓存中的知识
    protected long p1, p2, p3, p4, p5, p6, p7;

    //构造方法
    RingBuffer(
            EventFactory<E> eventFactory,
            Sequencer sequencer)
    {
        super(eventFactory, sequencer);
    }

//    public static <E> RingBuffer<E> createMultiProducer(
//            EventFactory<E> factory,
//            int bufferSize,
//            WaitStrategy waitStrategy)
//    {
//        MultiProducerSequencer sequencer = new MultiProducerSequencer(bufferSize, waitStrategy);
//
//        return new RingBuffer<E>(factory, sequencer);
//    }


//    public static <E> RingBuffer<E> createMultiProducer(EventFactory<E> factory, int bufferSize)
//    {
//        return createMultiProducer(factory, bufferSize, new BlockingWaitStrategy());
//    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/23
     * @Description:创建单生产者的序号生成器，在该方法中，环形数组也被创建了
     */
    public static <E> RingBuffer<E> createSingleProducer(
            EventFactory<E> factory,
            int bufferSize,
            WaitStrategy waitStrategy)
    {
        //创建单生产者序列号生成器
        SingleProducerSequencer sequencer = new SingleProducerSequencer(bufferSize, waitStrategy);
        //创建环形数组
        return new RingBuffer<E>(factory, sequencer);
    }


//    public static <E> RingBuffer<E> createSingleProducer(EventFactory<E> factory, int bufferSize)
//    {
//        return createSingleProducer(factory, bufferSize, new BlockingWaitStrategy());
//    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:创建环形数组和单生产者序号生成器的方法
     */
    public static <E> RingBuffer<E> create(
            ProducerType producerType,
            EventFactory<E> factory,
            int bufferSize,
            WaitStrategy waitStrategy)
    {
        switch (producerType)
        {
            //创建单生产者模式下的序列号生成器
            case SINGLE:
                return createSingleProducer(factory, bufferSize, waitStrategy);
                //下面创建的是多生产者序号生成器，但多生产者还未引入，所以先注释了
//            case MULTI:
//                return createMultiProducer(factory, bufferSize, waitStrategy);
            default:
                throw new IllegalStateException(producerType.toString());
        }
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:根据序号获得环形数组中对应的元素
     */
    @Override
    public E get(long sequence)
    {
        return elementAt(sequence);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:获取下一个可用的序号，然后交给生产者使用，真正干活的是序号生成器
     * 该方法每次只会申请一个可用序号
     */
    @Override
    public long next()
    {
        return sequencer.next();
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:该方法和上面那个方法一样，也是获取可用的序号交给生产者使用，但是该方法会传入参数，
     * 如果传入的是5，那么就要一次获得5个可用的序号
     */
    @Override
    public long next(int n)
    {
        return sequencer.next(n);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:尝试申请一个可用序号
     */
    @Override
    public long tryNext() throws InsufficientCapacityException
    {
        return sequencer.tryNext();
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:尝试申请多个可用序号
     */
    @Override
    public long tryNext(int n) throws InsufficientCapacityException
    {
        return sequencer.tryNext(n);
    }

    //将生产者的进度序号指定为sequence
    @Deprecated
    public void resetTo(long sequence)
    {
        sequencer.claim(sequence);
        //通知其他消费者这个序号位置可以消费了
        sequencer.publish(sequence);
    }

    //用不到的方法暂时不讲
    public E claimAndGetPreallocated(long sequence)
    {
        sequencer.claim(sequence);
        return get(sequence);
    }

    //判断该序号是否可用
    @Deprecated
    public boolean isPublished(long sequence)
    {
        return sequencer.isAvailable(sequence);
    }

    //把新添加进来的消费者的消费序号添加到gatingSequences数组中
    public void addGatingSequences(Sequence... gatingSequences)
    {
        sequencer.addGatingSequences(gatingSequences);
    }

    //得到所有消费者序号和当前生产者序号中最小的那个序号
    public long getMinimumGatingSequence()
    {
        return sequencer.getMinimumSequence();
    }

    //从gatingSequences数组中删除不必在关注的消费者的消费序号
    public boolean removeGatingSequence(Sequence sequence)
    {
        return sequencer.removeGatingSequence(sequence);
    }

    //为消费者创建序号屏障
    public SequenceBarrier newBarrier(Sequence... sequencesToTrack)
    {
        return sequencer.newBarrier(sequencesToTrack);
    }


//    public EventPoller<E> newPoller(Sequence... gatingSequences)
//    {
//        return sequencer.newPoller(this, gatingSequences);
//    }

    //获得当前生产者的序号
    @Override
    public long getCursor()
    {
        return sequencer.getCursor();
    }

    //获得环形数组的有效容量
    public int getBufferSize()
    {
        return bufferSize;
    }

    //是否可以申请指定的序号数量
    public boolean hasAvailableCapacity(int requiredCapacity)
    {
        return sequencer.hasAvailableCapacity(requiredCapacity);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:发布生产者数据的核心方法，但在这一个版本中使用的并不是这个方法
     */
    @Override
    public void publishEvent(EventTranslator<E> translator)
    {   //首先获得可用的生产者序号
        final long sequence = sequencer.next();
        translateAndPublish(translator, sequence);
    }


//    @Override
//    public boolean tryPublishEvent(EventTranslator<E> translator)
//    {
//        try
//        {
//            final long sequence = sequencer.tryNext();
//            translateAndPublish(translator, sequence);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:发布生产者数据的核心方法，在第一版本代码中使用的方法
     */
    @Override
    public <A> void publishEvent(EventTranslatorOneArg<E, A> translator, A arg0)
    {
        //首先获得可用的生产者序号，生产者发布的信息就可以存放到该位置
        final long sequence = sequencer.next();
        //然后在这个序号对应的位置发布数据
        translateAndPublish(translator, sequence, arg0);
    }


//    @Override
//    public <A> boolean tryPublishEvent(EventTranslatorOneArg<E, A> translator, A arg0)
//    {
//        try
//        {
//            final long sequence = sequencer.tryNext();
//            translateAndPublish(translator, sequence, arg0);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//


//    @Override
//    public <A, B> void publishEvent(EventTranslatorTwoArg<E, A, B> translator, A arg0, B arg1)
//    {
//        final long sequence = sequencer.next();
//        translateAndPublish(translator, sequence, arg0, arg1);
//    }
//


//    @Override
//    public <A, B> boolean tryPublishEvent(EventTranslatorTwoArg<E, A, B> translator, A arg0, B arg1)
//    {
//        try
//        {
//            final long sequence = sequencer.tryNext();
//            translateAndPublish(translator, sequence, arg0, arg1);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//


//    @Override
//    public <A, B, C> void publishEvent(EventTranslatorThreeArg<E, A, B, C> translator, A arg0, B arg1, C arg2)
//    {
//        final long sequence = sequencer.next();
//        translateAndPublish(translator, sequence, arg0, arg1, arg2);
//    }
//


//    @Override
//    public <A, B, C> boolean tryPublishEvent(EventTranslatorThreeArg<E, A, B, C> translator, A arg0, B arg1, C arg2)
//    {
//        try
//        {
//            final long sequence = sequencer.tryNext();
//            translateAndPublish(translator, sequence, arg0, arg1, arg2);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//


//    @Override
//    public void publishEvent(EventTranslatorVararg<E> translator, Object... args)
//    {
//        final long sequence = sequencer.next();
//        translateAndPublish(translator, sequence, args);
//    }
//


//    @Override
//    public boolean tryPublishEvent(EventTranslatorVararg<E> translator, Object... args)
//    {
//        try
//        {
//            final long sequence = sequencer.tryNext();
//            translateAndPublish(translator, sequence, args);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//


//    @Override
//    public void publishEvents(EventTranslator<E>[] translators)
//    {
//        publishEvents(translators, 0, translators.length);
//    }
//


//    @Override
//    public void publishEvents(EventTranslator<E>[] translators, int batchStartsAt, int batchSize)
//    {
//        checkBounds(translators, batchStartsAt, batchSize);
//        final long finalSequence = sequencer.next(batchSize);
//        translateAndPublishBatch(translators, batchStartsAt, batchSize, finalSequence);
//    }
//



//    @Override
//    public boolean tryPublishEvents(EventTranslator<E>[] translators)
//    {
//        return tryPublishEvents(translators, 0, translators.length);
//    }
//


//    @Override
//    public boolean tryPublishEvents(EventTranslator<E>[] translators, int batchStartsAt, int batchSize)
//    {
//        checkBounds(translators, batchStartsAt, batchSize);
//        try
//        {
//            final long finalSequence = sequencer.tryNext(batchSize);
//            translateAndPublishBatch(translators, batchStartsAt, batchSize, finalSequence);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//



//    @Override
//    public <A> void publishEvents(EventTranslatorOneArg<E, A> translator, A[] arg0)
//    {
//        publishEvents(translator, 0, arg0.length, arg0);
//    }
//



//    @Override
//    public <A> void publishEvents(EventTranslatorOneArg<E, A> translator, int batchStartsAt, int batchSize, A[] arg0)
//    {
//        checkBounds(arg0, batchStartsAt, batchSize);
//        final long finalSequence = sequencer.next(batchSize);
//        translateAndPublishBatch(translator, arg0, batchStartsAt, batchSize, finalSequence);
//    }
//



//    @Override
//    public <A> boolean tryPublishEvents(EventTranslatorOneArg<E, A> translator, A[] arg0)
//    {
//        return tryPublishEvents(translator, 0, arg0.length, arg0);
//    }
//



//    @Override
//    public <A> boolean tryPublishEvents(
//            EventTranslatorOneArg<E, A> translator, int batchStartsAt, int batchSize, A[] arg0)
//    {
//        checkBounds(arg0, batchStartsAt, batchSize);
//        try
//        {
//            final long finalSequence = sequencer.tryNext(batchSize);
//            translateAndPublishBatch(translator, arg0, batchStartsAt, batchSize, finalSequence);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//



//    @Override
//    public <A, B> void publishEvents(EventTranslatorTwoArg<E, A, B> translator, A[] arg0, B[] arg1)
//    {
//        publishEvents(translator, 0, arg0.length, arg0, arg1);
//    }
//



//    @Override
//    public <A, B> void publishEvents(
//            EventTranslatorTwoArg<E, A, B> translator, int batchStartsAt, int batchSize, A[] arg0, B[] arg1)
//    {
//        checkBounds(arg0, arg1, batchStartsAt, batchSize);
//        final long finalSequence = sequencer.next(batchSize);
//        translateAndPublishBatch(translator, arg0, arg1, batchStartsAt, batchSize, finalSequence);
//    }
//



//    @Override
//    public <A, B> boolean tryPublishEvents(EventTranslatorTwoArg<E, A, B> translator, A[] arg0, B[] arg1)
//    {
//        return tryPublishEvents(translator, 0, arg0.length, arg0, arg1);
//    }
//



//    @Override
//    public <A, B> boolean tryPublishEvents(
//            EventTranslatorTwoArg<E, A, B> translator, int batchStartsAt, int batchSize, A[] arg0, B[] arg1)
//    {
//        checkBounds(arg0, arg1, batchStartsAt, batchSize);
//        try
//        {
//            final long finalSequence = sequencer.tryNext(batchSize);
//            translateAndPublishBatch(translator, arg0, arg1, batchStartsAt, batchSize, finalSequence);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//



//    @Override
//    public <A, B, C> void publishEvents(EventTranslatorThreeArg<E, A, B, C> translator, A[] arg0, B[] arg1, C[] arg2)
//    {
//        publishEvents(translator, 0, arg0.length, arg0, arg1, arg2);
//    }
//



//    @Override
//    public <A, B, C> void publishEvents(
//            EventTranslatorThreeArg<E, A, B, C> translator, int batchStartsAt, int batchSize, A[] arg0, B[] arg1, C[] arg2)
//    {
//        checkBounds(arg0, arg1, arg2, batchStartsAt, batchSize);
//        final long finalSequence = sequencer.next(batchSize);
//        translateAndPublishBatch(translator, arg0, arg1, arg2, batchStartsAt, batchSize, finalSequence);
//    }
//



//    @Override
//    public <A, B, C> boolean tryPublishEvents(
//            EventTranslatorThreeArg<E, A, B, C> translator, A[] arg0, B[] arg1, C[] arg2)
//    {
//        return tryPublishEvents(translator, 0, arg0.length, arg0, arg1, arg2);
//    }
//



//    @Override
//    public <A, B, C> boolean tryPublishEvents(
//            EventTranslatorThreeArg<E, A, B, C> translator, int batchStartsAt, int batchSize, A[] arg0, B[] arg1, C[] arg2)
//    {
//        checkBounds(arg0, arg1, arg2, batchStartsAt, batchSize);
//        try
//        {
//            final long finalSequence = sequencer.tryNext(batchSize);
//            translateAndPublishBatch(translator, arg0, arg1, arg2, batchStartsAt, batchSize, finalSequence);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }
//



//    @Override
//    public void publishEvents(EventTranslatorVararg<E> translator, Object[]... args)
//    {
//        publishEvents(translator, 0, args.length, args);
//    }
//



//    @Override
//    public void publishEvents(EventTranslatorVararg<E> translator, int batchStartsAt, int batchSize, Object[]... args)
//    {
//        checkBounds(batchStartsAt, batchSize, args);
//        final long finalSequence = sequencer.next(batchSize);
//        translateAndPublishBatch(translator, batchStartsAt, batchSize, finalSequence, args);
//    }
//



//    @Override
//    public boolean tryPublishEvents(EventTranslatorVararg<E> translator, Object[]... args)
//    {
//        return tryPublishEvents(translator, 0, args.length, args);
//    }
//



//    @Override
//    public boolean tryPublishEvents(
//            EventTranslatorVararg<E> translator, int batchStartsAt, int batchSize, Object[]... args)
//    {
//        checkBounds(args, batchStartsAt, batchSize);
//        try
//        {
//            final long finalSequence = sequencer.tryNext(batchSize);
//            translateAndPublishBatch(translator, batchStartsAt, batchSize, finalSequence, args);
//            return true;
//        }
//        catch (InsufficientCapacityException e)
//        {
//            return false;
//        }
//    }


    //通知其他消费者这个序号位置可以消费了
    @Override
    public void publish(long sequence)
    {
        sequencer.publish(sequence);
    }

    //通知其他消费者这个hi序号位置之前的数据都可以消费了
    @Override
    public void publish(long lo, long hi)
    {
        sequencer.publish(lo, hi);
    }

    //环形数组中的剩余容量
    public long remainingCapacity()
    {
        return sequencer.remainingCapacity();
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:下面这些方法都没有用到，所以就不讲了
     */
    private void checkBounds(final EventTranslator<E>[] translators, final int batchStartsAt, final int batchSize)
    {
        checkBatchSizing(batchStartsAt, batchSize);
        batchOverRuns(translators, batchStartsAt, batchSize);
    }

    private void checkBatchSizing(int batchStartsAt, int batchSize)
    {
        if (batchStartsAt < 0 || batchSize < 0)
        {
            throw new IllegalArgumentException("Both batchStartsAt and batchSize must be positive but got: batchStartsAt " + batchStartsAt + " and batchSize " + batchSize);
        }
        else if (batchSize > bufferSize)
        {
            throw new IllegalArgumentException("The ring buffer cannot accommodate " + batchSize + " it only has space for " + bufferSize + " entities.");
        }
    }

    private <A> void checkBounds(final A[] arg0, final int batchStartsAt, final int batchSize)
    {
        checkBatchSizing(batchStartsAt, batchSize);
        batchOverRuns(arg0, batchStartsAt, batchSize);
    }

    private <A, B> void checkBounds(final A[] arg0, final B[] arg1, final int batchStartsAt, final int batchSize)
    {
        checkBatchSizing(batchStartsAt, batchSize);
        batchOverRuns(arg0, batchStartsAt, batchSize);
        batchOverRuns(arg1, batchStartsAt, batchSize);
    }

    private <A, B, C> void checkBounds(
            final A[] arg0, final B[] arg1, final C[] arg2, final int batchStartsAt, final int batchSize)
    {
        checkBatchSizing(batchStartsAt, batchSize);
        batchOverRuns(arg0, batchStartsAt, batchSize);
        batchOverRuns(arg1, batchStartsAt, batchSize);
        batchOverRuns(arg2, batchStartsAt, batchSize);
    }

    private void checkBounds(final int batchStartsAt, final int batchSize, final Object[][] args)
    {
        checkBatchSizing(batchStartsAt, batchSize);
        batchOverRuns(args, batchStartsAt, batchSize);
    }

    private <A> void batchOverRuns(final A[] arg0, final int batchStartsAt, final int batchSize)
    {
        if (batchStartsAt + batchSize > arg0.length)
        {
            throw new IllegalArgumentException(
                    "A batchSize of: " + batchSize +
                            " with batchStatsAt of: " + batchStartsAt +
                            " will overrun the available number of arguments: " + (arg0.length - batchStartsAt));
        }
    }

    private void translateAndPublish(EventTranslator<E> translator, long sequence)
    {
        try
        {
            translator.translateTo(get(sequence), sequence);
        }
        finally
        {
            sequencer.publish(sequence);
        }
    }

    private <A> void translateAndPublish(EventTranslatorOneArg<E, A> translator, long sequence, A arg0)
    {
        try
        {
            translator.translateTo(get(sequence), sequence, arg0);
        }
        finally
        {
            sequencer.publish(sequence);
        }
    }


//    private <A, B> void translateAndPublish(EventTranslatorTwoArg<E, A, B> translator, long sequence, A arg0, B arg1)
//    {
//        try
//        {
//            translator.translateTo(get(sequence), sequence, arg0, arg1);
//        }
//        finally
//        {
//            sequencer.publish(sequence);
//        }
//    }


//    private <A, B, C> void translateAndPublish(
//            EventTranslatorThreeArg<E, A, B, C> translator, long sequence,
//            A arg0, B arg1, C arg2)
//    {
//        try
//        {
//            translator.translateTo(get(sequence), sequence, arg0, arg1, arg2);
//        }
//        finally
//        {
//            sequencer.publish(sequence);
//        }
//    }


//    private void translateAndPublish(EventTranslatorVararg<E> translator, long sequence, Object... args)
//    {
//        try
//        {
//            translator.translateTo(get(sequence), sequence, args);
//        }
//        finally
//        {
//            sequencer.publish(sequence);
//        }
//    }


//    private void translateAndPublishBatch(
//            final EventTranslator<E>[] translators, int batchStartsAt,
//            final int batchSize, final long finalSequence)
//    {
//        final long initialSequence = finalSequence - (batchSize - 1);
//        try
//        {
//            long sequence = initialSequence;
//            final int batchEndsAt = batchStartsAt + batchSize;
//            for (int i = batchStartsAt; i < batchEndsAt; i++)
//            {
//                final EventTranslator<E> translator = translators[i];
//                translator.translateTo(get(sequence), sequence++);
//            }
//        }
//        finally
//        {
//            sequencer.publish(initialSequence, finalSequence);
//        }
//    }


//    private <A> void translateAndPublishBatch(
//            final EventTranslatorOneArg<E, A> translator, final A[] arg0,
//            int batchStartsAt, final int batchSize, final long finalSequence)
//    {
//        final long initialSequence = finalSequence - (batchSize - 1);
//        try
//        {
//            long sequence = initialSequence;
//            final int batchEndsAt = batchStartsAt + batchSize;
//            for (int i = batchStartsAt; i < batchEndsAt; i++)
//            {
//                translator.translateTo(get(sequence), sequence++, arg0[i]);
//            }
//        }
//        finally
//        {
//            sequencer.publish(initialSequence, finalSequence);
//        }
//    }


//    private <A, B> void translateAndPublishBatch(
//            final EventTranslatorTwoArg<E, A, B> translator, final A[] arg0,
//            final B[] arg1, int batchStartsAt, int batchSize,
//            final long finalSequence)
//    {
//        final long initialSequence = finalSequence - (batchSize - 1);
//        try
//        {
//            long sequence = initialSequence;
//            final int batchEndsAt = batchStartsAt + batchSize;
//            for (int i = batchStartsAt; i < batchEndsAt; i++)
//            {
//                translator.translateTo(get(sequence), sequence++, arg0[i], arg1[i]);
//            }
//        }
//        finally
//        {
//            sequencer.publish(initialSequence, finalSequence);
//        }
//    }


//    private <A, B, C> void translateAndPublishBatch(
//            final EventTranslatorThreeArg<E, A, B, C> translator,
//            final A[] arg0, final B[] arg1, final C[] arg2, int batchStartsAt,
//            final int batchSize, final long finalSequence)
//    {
//        final long initialSequence = finalSequence - (batchSize - 1);
//        try
//        {
//            long sequence = initialSequence;
//            final int batchEndsAt = batchStartsAt + batchSize;
//            for (int i = batchStartsAt; i < batchEndsAt; i++)
//            {
//                translator.translateTo(get(sequence), sequence++, arg0[i], arg1[i], arg2[i]);
//            }
//        }
//        finally
//        {
//            sequencer.publish(initialSequence, finalSequence);
//        }
//    }


//    private void translateAndPublishBatch(
//            final EventTranslatorVararg<E> translator, int batchStartsAt,
//            final int batchSize, final long finalSequence, final Object[][] args)
//    {
//        final long initialSequence = finalSequence - (batchSize - 1);
//        try
//        {
//            long sequence = initialSequence;
//            final int batchEndsAt = batchStartsAt + batchSize;
//            for (int i = batchStartsAt; i < batchEndsAt; i++)
//            {
//                translator.translateTo(get(sequence), sequence++, args[i]);
//            }
//        }
//        finally
//        {
//            sequencer.publish(initialSequence, finalSequence);
//        }
//    }

    @Override
    public String toString()
    {
        return "RingBuffer{" +
                "bufferSize=" + bufferSize +
                ", sequencer=" + sequencer +
                "}";
    }
}
