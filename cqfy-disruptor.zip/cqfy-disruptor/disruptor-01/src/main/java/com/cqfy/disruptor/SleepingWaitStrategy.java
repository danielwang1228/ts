package com.cqfy.disruptor;

import java.util.concurrent.locks.LockSupport;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/23
 * @Description:等待策略，该框架内部有很多等待策略，我在第一版本引入的是比较简单的一种
 */
public final class SleepingWaitStrategy implements WaitStrategy
{
    //默认的自旋次数
    private static final int DEFAULT_RETRIES = 200;
    //默认的睡眠时间
    private static final long DEFAULT_SLEEP = 100;

    private final int retries;
    private final long sleepTimeNs;

    //该构造方法会被调用
    public SleepingWaitStrategy()
    {
        this(DEFAULT_RETRIES, DEFAULT_SLEEP);
    }

    public SleepingWaitStrategy(int retries)
    {
        this(retries, DEFAULT_SLEEP);
    }

    public SleepingWaitStrategy(int retries, long sleepTimeNs)
    {
        this.retries = retries;
        this.sleepTimeNs = sleepTimeNs;
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/23
     * @Description:获取可消费的最大进度额核心方法
     */
    @Override
    public long waitFor(
            final long sequence, Sequence cursor, final Sequence dependentSequence, final SequenceBarrier barrier)
            throws AlertException
    {
        long availableSequence;
        //在这里得到默认的自旋次数
        int counter = retries;
        //下面的判断条件中，dependentSequence是消费者要依赖的其他消费者的消费进度，而sequence就是当前消费者
        //申请的想使用的消费序号。在第一版本中，我们并没有考虑消费者的顺序消费情况，所以消费者并不依赖其他任何消费者
        //只需要判断生产者的进度即可，所以在ProcessingSequenceBarrier类中dependentSequence会被生产者的进度赋值，所以
        //这里dependentSequence.get()得到的就是生产者当前的进度序号，并且是最新进度的序号，这个序号会赋值给availableSequence
        //并且判断是否小于sequence，如果大于则说明生产进度超过了消费进度，那就把可用的生产序号直接返回给消费者消费就行
        //如果小于，则说明当前生产者的进度是落后消费者的，比如说消费者想消费的进度是5，但生产者只发布到了4，显然，消费者
        //应该等待一会，等待生产者的进度到5或者超过5，才能继续消费
        while ((availableSequence = dependentSequence.get()) < sequence)
        {
            //在这里让线程等待，直到生产者发布了新的数据，其进度更新了，超过了消费者的进度
            counter = applyWaitMethod(barrier, counter);
        }
        //返回可用的最大进度
        return availableSequence;
    }

    //下面这个方法要结合applyWaitMethod方法来学习，也就是最下面的方法
    //这个方法会被消费者线程得到了被终止的信号后调用，意思是如果有消费者线程在睡眠阻塞，就唤醒该线程，让该线程去
    //响应终止的信号。但是，在该等待策略中，可以发现，线程其实是没有阻塞的，因为一直在自旋，即便LockSupport.parkNanos(sleepTimeNs)
    //了一会，也马上就醒了，然后会进入到applyWaitMethod方法的第一行代码， barrier.checkAlert()检测消费者线程是否
    //要终止了，如果要终止就抛出一个异常，根本就没怎么阻塞，所以这里索性就做了一个空实现
    @Override
    public void signalAllWhenBlocking()
    {
    }

    private int applyWaitMethod(final SequenceBarrier barrier, int counter)
            throws AlertException
    {
        //检查消费者是否要被终止了
        barrier.checkAlert();
        //这里我要强调一下，counter在外层方法被retries赋值了，而retries被DEFAULT_RETRIES赋值了，是200
        //这意味着自旋次数是200，所谓自旋，就是让线程空转，就是下面这样，每空转1次，就让自旋次数减1
        if (counter > 100)
        {
            --counter;
        }
        //如果自旋次数小于100，大于0了，说明已经自旋了很多次了，但还是不能继续向下工作，这时候尝试让该线程让出CPU
        else if (counter > 0)
        {
            --counter;
            Thread.yield();
        }
        else
        {   //走到这里意味着自旋次数到达200了，这时候就干脆让线程睡一会吧
            //睡的时间就是100纳秒，不能睡得太久，因为生产者可能随时发布新的数据
            LockSupport.parkNanos(sleepTimeNs);
        }
        //这里返回剩余的自旋次数
        return counter;
    }
}