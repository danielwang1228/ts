package com.cqfy.disruptor;


//环形数组会实现这个接口
public interface DataProvider<T>
{

    T get(long sequence);
}