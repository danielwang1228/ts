package com.cqfy.disruptor.dsl;

import com.cqfy.disruptor.Sequence;
import com.cqfy.disruptor.SequenceBarrier;

import java.util.concurrent.Executor;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/17
 * @Description:该接口的实现类就是用来封装消费者信息的，该接口的实现类就是EventProcessorInfo
 * 而每一个EventProcessorInfo都对应着一个消费者，换句话说，每一个消费者都会被包装到EventProcessorInfo
 * 对象中，等真正启动消费者线程的时候，最后就会调用到EventProcessorInfo对象中的start方法
 */
interface ConsumerInfo
{

    //这个方法就是用来获得消费者的消费进度的，也就是消费者消费到哪个序号了
    Sequence[] getSequences();

    //该方法就是用来得到消费者的序号屏障
    //序号屏障究竟是什么，会在SequenceBarrier接口的实现类中详细介绍
    SequenceBarrier getBarrier();

    //这个方法就是判断当前消费者是否为消费者序列中的最后一个消费者，也就是消费进度最慢的消费者
    //举一个稍微形象一点的例子，如果有5个消费者都在消费环形数组中的数据，现在这5个消费者消费的进度不同
    //有的消费到数组的第5个索引位置了，而最慢的才消费到第3个索引位置
    //如果生产者想往环形数组中添加数据，必须要等消费最慢的那个消费者把第3索引的数据消费了，才能使用第3索引的位置存放数据
    boolean isEndOfChain();

    //启动程序的方法，其实就是启动所有消费者线程
    void start(Executor executor);

    //该方法就是用来终止线程工作的
    void halt();

    //如果当前消费者是最慢消费者，但这时候有比它更慢的了
    //这个方法就会把当前消费者的最慢消费者身份更改掉，表示它不是最慢消费者了
    void markAsUsedInBarrier();

    //判断当前消费者线程是否还在运行
    boolean isRunning();
}
