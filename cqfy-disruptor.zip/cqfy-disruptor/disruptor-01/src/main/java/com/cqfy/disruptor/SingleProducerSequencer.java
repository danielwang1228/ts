package com.cqfy.disruptor;

import com.cqfy.disruptor.util.Util;

import java.util.concurrent.locks.LockSupport;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/24
 * @Description:序号生成器类，该类也用到了空白字节填充来解决伪共享问题
 */
abstract class SingleProducerSequencerPad extends AbstractSequencer
{
    protected long p1, p2, p3, p4, p5, p6, p7;

    SingleProducerSequencerPad(int bufferSize, WaitStrategy waitStrategy)
    {
        super(bufferSize, waitStrategy);
    }
}

abstract class SingleProducerSequencerFields extends SingleProducerSequencerPad
{
    SingleProducerSequencerFields(int bufferSize, WaitStrategy waitStrategy)
    {
        super(bufferSize, waitStrategy);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:该成员变量就是当前分配的可用的序号，可以看到初始值也是-1L
     */
    long nextValue = Sequence.INITIAL_VALUE;

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:这个成员变量也很重要，大家应该还记得AbstractSequencer类中的gatingSequences成员变量吧，是个数组
     * 这个数组中存储的都是消费者的消费进度，通过这个数组，就能找到所有消费者中，消费最慢的那个进度。最慢的消费者进度就会被赋值给下面的这个
     * 成员变量，所以查找最慢的消费者变量时并不是直接去数组中查看，而是根据这个缓存值获得
     * 这个缓存值的初始值也是-1
     */
    long cachedValue = Sequence.INITIAL_VALUE;
}

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/24
 * @Description:单生产者使用的序号生成器
 */
public final class SingleProducerSequencer extends SingleProducerSequencerFields
{
    //解决伪共享填充的字节
    protected long p1, p2, p3, p4, p5, p6, p7;

    //构造方法
    public SingleProducerSequencer(int bufferSize, WaitStrategy waitStrategy)
    {
        super(bufferSize, waitStrategy);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:判断是否有充足的容量分配需要的序号数量，注意这里只是判断是否有足够的容量，并不是真的要分配这么多序号
     */
    @Override
    public boolean hasAvailableCapacity(int requiredCapacity)
    {
        return hasAvailableCapacity(requiredCapacity, false);
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:真正判断是否有充足的容量分配需要的序号数量的方法
     */
    private boolean hasAvailableCapacity(int requiredCapacity, boolean doStore)
    {
        //先得到当前的已分配到的序号，比如当前就分配到13了
        long nextValue = this.nextValue;
        //下面这里的计算很重要，现在我们知道nextValue序号是13了，比如说要申请的requiredCapacity是5，那么13加5是18
        //比如说bufferSize是8，那么最后得到的差值就是10
        //这是不是就意味着，申请之后的生产者进度实际上比整个环形数组的容量大了十个，也就是说生产者的进度在第一次填满环形数组后
        //还能进行第二次填满，然后还多出来两个要填冲
        long wrapPoint = (nextValue + requiredCapacity) - bufferSize;
        //得到最慢的消费者的消费进度，比如说就消费到序号9了，大家可以想一想，如果上面得到的这个wrapPoint小于0，是不是意味着
        //生产者连环形数组的一圈都还没有填充完呢，所以，不管消费者消费到哪里了，都不会出现覆盖还未被消费的数据的情况。就是生产者
        //填充了环形数组一圈了，然后将要填充的位置就要覆盖了消费者还未消费的数据，在wrapPoint小于0的时候，是不会出现的
        //如果wrapPoint大于0呢？说明加上要申请的序号requiredCapacity，生产者肯定已经填充了环形数组一圈了，再次填充
        //肯定就是和掩码做位元算，然后从数组头部重新填充，这就有可能把尚未消费的数据覆盖掉，所以，接下来，程序就要避免这种情况出现
        //在上面得到的wrapPoint结果是10，而现在最慢的消费者才消费到9，环形数组长度是8
        //加上之前填充的那一轮，这是不是意味生产者已经填充了两次环形数组，该填充第三次了，第三次要填充2个数据，正好是数组的0号位置和1号位置
        //恰好会把第二轮填充的0号位和1号位覆盖掉
        //而当前的消费者的消费进度是9，也就是填充的第二轮的0号位，1号位还未被消费，但是要被生产者覆盖了，这就很尴尬了，所以，我们要避免这种情况出现
        //注意啊，这里并没有真的覆盖，因为一切的基础都建立在这个要申请的requiredCapacity之上，这里只是判断能不能分配requiredCapacity数量的
        //序号供生产者使用，现在这种情况肯定就不能分配了呀，所以要采取一些措施
        long cachedGatingSequence = this.cachedValue;
        //这里就判断了wrapPoint > cachedGatingSequence，这不就是我刚才为大家分析的情况吗？
        //cachedGatingSequence是最慢的消费者的进度序号，是不可能大于nextValue这个生产者的进度的
        //所以只看前面的判断即可
        if (wrapPoint > cachedGatingSequence || cachedGatingSequence > nextValue)
        {
            //doStore为true的话，就意味着要立即用Volatile的方式更新一下生产者最新的进度，以便让消费者线程立刻看到，然后去消费
            if (doStore)
            {   //用Volatile更新生产者进度
                cursor.setVolatile(nextValue);
            }
            //这里就是得到最小的消费者进度
            long minSequence = Util.getMinimumSequence(gatingSequences, nextValue);
            //把最小的消费者进度缓存一下，因为cachedValue可能不是最新的值，因为消费者进度也不是使用Volatile方式更新的
            //不保证立即可见性，所以，上面的判断可能是基于旧的消费者进度判断的，发现可能覆盖未被消费的数据后，立刻重新查询一下
            //最新的当前最慢消费者进度
            this.cachedValue = minSequence;
            //这里再判断一下，看看最新的当前最慢消费者进度是否还小于wrapPoint
            //小于就意味着仍然会覆盖尚未消费的数据
            if (wrapPoint > minSequence)
            {   //所以返回false即可，表示没有足够的容量分配这么多序号
                return false;
            }
        }
        //走到这里意味着有足够的容量
        return true;
    }

    //申请一个可用的序号的方法
    @Override
    public long next()
    {   //这里可以看到，默认只申请一个
        return next(1);
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:申请指定数量的序号，交给生产者使用
     */
    @Override
    public long next(int n)
    {   //判断是否小于1
        if (n < 1)
        {   //抛出异常
            throw new IllegalArgumentException("n must be > 0");
        }
        //先得到当前的序号，这个序号就是序号生成器已经分配好了的序号
        //其实也就可以代表生产者的最新进度
        long nextValue = this.nextValue;
        //加上要申请的序号的个数，得到最终要申请到的序号的值
        long nextSequence = nextValue + n;
        //这里的逻辑其实和上面hasAvailableCapacity分析的逻辑一样
        //都是为了判断是否会覆盖尚未被消费的数据
        long wrapPoint = nextSequence - bufferSize;
        //得到消费者中最慢的那个消费进度
        long cachedGatingSequence = this.cachedValue;
        //和之前hasAvailableCapacity分析的逻辑一摸一样，就不再重复注释了
        if (wrapPoint > cachedGatingSequence || cachedGatingSequence > nextValue)
        {   //这里有点不一样，如果发现快要覆盖未消费的数据了，就立刻更新一下生产者当前的进度
            //并且保证内存可见
            cursor.setVolatile(nextValue);
            //定义一个记录最慢消费进度的局部变量
            long minSequence;
            //这里就和hasAvailableCapacity方法的逻辑不同了，注意，这里是要真正的分配序号了，如果分配不了，就要让线程等待，直到能够分配为止
            //minSequence = Util.getMinimumSequence(gatingSequences, nextValue)得到的是最新的最慢消费者的进度
            //所以下面会判断，wrapPoint是不是一直大于最新的最慢消费者进度，如果大于，就不能分配，只有小于的时候，才能分配
            while (wrapPoint > (minSequence = Util.getMinimumSequence(gatingSequences, nextValue)))
            {   //源码在这里其实有一个TODO，打算用等待策略来扩展这里的LockSupport
                //但是一直没有实现，该类最后一次更新已经是去年了，这个扩展也没实现
                LockSupport.parkNanos(1L);
            }
            //把最新的最慢消费者进度的缓存更新一下
            this.cachedValue = minSequence;
        }
        //走到这里，说明当前的生产者线程已经不阻塞了，因为在上面循环中的等待，已经让消费者把该消费的数据都消费了
        //所以，这里就可以直接把最新的要分配的序号赋值给nextValue成员变量了，意味着这个最新的值可以分配给生产者使用了
        this.nextValue = nextSequence;
        //返回最新的分配出来的序号，交给生产者使用
        return nextSequence;
    }

    //尝试申请1个可用的序号
    @Override
    public long tryNext() throws InsufficientCapacityException
    {
        return tryNext(1);
    }

    //尝试申请可用的n个序号
    @Override
    public long tryNext(int n) throws InsufficientCapacityException
    {
        if (n < 1)
        {
            throw new IllegalArgumentException("n must be > 0");
        }
        //这里就直接判断一下，看是否可以申请这么多，这个方法的逻辑上面已经详细分析过了
        if (!hasAvailableCapacity(n, true))
        {
            throw InsufficientCapacityException.INSTANCE;
        }
        //走到这里，说明完全可以申请，所以直接计算出最新的可用序号，然后返回即可
        long nextSequence = this.nextValue += n;

        return nextSequence;
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:得到剩余的环形数组的容量
     */
    @Override
    public long remainingCapacity()
    {   //得到当前使用的生产者序号
        long nextValue = this.nextValue;
        //得到消费进度最慢的消费者的序号
        long consumed = Util.getMinimumSequence(gatingSequences, nextValue);
        long produced = nextValue;
        //比如生产者的序号是9，消费者的序号是7，环形数组的容量是8，9-7得到就是可以使用的消费者序号的个数，也就是2个
        //这就意味着环形数组中还有2个数据没有被消费，占用了2个位置，环形数组的容量减去被占用的位置，得到的就是
        //剩下的环形数组的容量
        return getBufferSize() - (produced - consumed);
    }

    //将生产者的进度序号指定为sequence
    @Override
    public void claim(long sequence)
    {
        this.nextValue = sequence;
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/24
     * @Description:发布可以被消费的生产者序号的方法，然后通知其他消费者来消费
     */
    @Override
    public void publish(long sequence)
    {   //发布序号
        cursor.set(sequence);
        //通知其他消费者消费，实际上就是环形阻塞的消费者线程
        waitStrategy.signalAllWhenBlocking();
    }


    @Override
    public void publish(long lo, long hi)
    {
        publish(hi);
    }


    @Override
    public boolean isAvailable(long sequence)
    {
        return sequence <= cursor.get();
    }


    @Override
    public long getHighestPublishedSequence(long lowerBound, long availableSequence)
    {
        return availableSequence;
    }
}
