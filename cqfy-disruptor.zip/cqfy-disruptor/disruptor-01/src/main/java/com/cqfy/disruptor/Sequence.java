package com.cqfy.disruptor;

import com.cqfy.disruptor.util.Util;
import sun.misc.Unsafe;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/24
 * @Description:生产者和消费者使用的序号对象，其实就是一个long整数，但是为了解决伪共享，就把这个long整数封装在一个Sequence对象中了
 */
class LhsPadding
{   //在父类填充空字节
    protected long p1, p2, p3, p4, p5, p6, p7;
}

class Value extends LhsPadding
{
    //value前后都有7个空的long整数，也就是56个空白字节，加上当前的value正好是64个字节
    //高速缓存一行缓存64个字节，这样不管怎么读取这个value，它都会自己独占一个缓存行，不会出现伪共享了
    protected volatile long value;
}

class RhsPadding extends Value
{   //在子类填充空字节
    protected long p9, p10, p11, p12, p13, p14, p15;
}

public class Sequence extends RhsPadding
{   //消费进度初始值，默认为-1
    static final long INITIAL_VALUE = -1L;
    //Unsafe对象
    private static final Unsafe UNSAFE;
    //value在对象中的内存偏移量
    private static final long VALUE_OFFSET;

    static
    {
        UNSAFE = Util.getUnsafe();
        try
        {   //该方法的作用在环形数组类也见过了，就是得到value在对象中的内存偏移量，这样就能直接根据内存偏移量，让Unsafe对象直接操纵这个变量了
            VALUE_OFFSET = UNSAFE.objectFieldOffset(Value.class.getDeclaredField("value"));
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
    }
    //构造方法
    public Sequence()
    {
        this(INITIAL_VALUE);
    }

    //设置value的初始值，也就是-1L
    public Sequence(final long initialValue)
    {
        UNSAFE.putOrderedLong(this, VALUE_OFFSET, initialValue);
    }

    //返回value
    public long get()
    {
        return value;
    }

    //设置value的值
    public void set(final long value)
    {   //putOrderedLong方法并不会保证内存的立即可见性，只会保证不被指令重拍，也就是说，更新了value，该值可能并不会立刻被其他线程可见
        //因此该方法更新value会比下面的方法稍微快一点，这也就导致了消费者不能总是立刻得到最新的生产者进度，但这没有关系
        //反正总会被消耗到。由此也可以看出，这个框架为了尽量提升性能，真的是用尽了很多手段
        //当然，这些手段其他框架也都用过，实际上Netty中也有这样的方法
        //当然，我还要强调一点，这个方法设置不会被其它线程立刻看到，但并不是说不会看到，只是有一定延迟，可能会有几纳秒
        UNSAFE.putOrderedLong(this, VALUE_OFFSET, value);
    }

    //使用Volatile设置value的值，因为是Volatile，所以该方法就保证了内存可见性，同时也禁止了指令重排
    //因为保证了立即可见性，更新的value是要写入到主存中的，这样才能被各个线程看见，所以写入的动作会稍微慢一下
    public void setVolatile(final long value)
    {
        UNSAFE.putLongVolatile(this, VALUE_OFFSET, value);
    }

    //该方法是在多生产者模式下使用的方法
    public boolean compareAndSet(final long expectedValue, final long newValue)
    {
        return UNSAFE.compareAndSwapLong(this, VALUE_OFFSET, expectedValue, newValue);
    }


    public long incrementAndGet()
    {
        return addAndGet(1L);
    }


    public long addAndGet(final long increment)
    {
        long currentValue;
        long newValue;

        do
        {
            currentValue = get();
            newValue = currentValue + increment;
        }
        while (!compareAndSet(currentValue, newValue));

        return newValue;
    }

    @Override
    public String toString()
    {
        return Long.toString(get());
    }
}
