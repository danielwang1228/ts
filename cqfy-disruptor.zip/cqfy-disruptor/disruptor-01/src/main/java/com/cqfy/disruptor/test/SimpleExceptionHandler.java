package com.cqfy.disruptor.test;

import com.cqfy.disruptor.ExceptionHandler;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/8
 * @Description:用户自己定义的异常处理器，这里为什么要让用户自己定义一个异常处理器呢，因为程序内部的异常处理反应比较强烈
 * 一旦出现异常，该框架自带的FatalExceptionHandler异常处理器会直接强制终止消费者消费，也就是直接退出程序的意思
 * 显然这个力度有些大了，所以该框架就定义了一个接口暴露给用户使用，用户可以定义一些自己想要的处理异常的逻辑
 */
public class SimpleExceptionHandler<T> implements ExceptionHandler<Event<T>> {

    //处理事件时出现异常的解决方法，为了简化，我就只打印一句话了
    @Override
    public void handleEventException(Throwable ex, long sequence, Event<T> event) {
        System.out.println("出现了异常了"+ex);
    }

    //启动程序时出现异常的解决方法
    @Override
    public void handleOnStartException(Throwable ex) {
        System.out.println("出现了异常了"+ex);
    }

    //终止程序时出现异常的解决方法
    @Override
    public void handleOnShutdownException(Throwable ex) {
        System.out.println("出现了异常了"+ex);
    }
}
