package com.cqfy.disruptor.dsl;

import com.cqfy.disruptor.EventProcessor;
import com.cqfy.disruptor.RingBuffer;
import com.cqfy.disruptor.Sequence;

//这个接口是对用户暴露的，在这个接口的实现类中，用户可以直接定义
//创建EventProcessor对象的逻辑，这里我们用不到它，所以就先不演示了
public interface EventProcessorFactory<T>
{

    EventProcessor createEventProcessor(RingBuffer<T> ringBuffer, Sequence[] barrierSequences);
}

