package com.cqfy.disruptor.test;


import org.openjdk.jol.info.ClassLayout;

class ObjectTest {

    protected long p1, p2, p3, p4, p5, p6, p7;

    private long p8;

    protected long p9, p10, p11, p12, p13, p14, p15;

    public static void main(String[] args) {
        //System.out.println(RamUsageEstimator.sizeOf(new ObjectTest()));



        //Jbject a = new Jbject();
        //System.out.println(ClassLayout.parseInstance(a).toPrintable());

        ObjectTest b = new ObjectTest();
        System.out.println(ClassLayout.parseInstance(b).toPrintable());



        //SizeOf sizeOf = SizeOf.newInstance();
        //System.out.println(sizeOf.sizeOf(new Jbject()));
    }
}