package com.cqfy.disruptor;

import com.cqfy.disruptor.util.Util;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/19
 * @Description:序号生成器的抽象父类，该类再往下细分会有多生产者序号生成器和单生产者序号生成器
 * 在第一版本代码中，我只为大家引入了单生产者序号生成器，也就是SingleProducerSequencer类
 */
public abstract class AbstractSequencer implements Sequencer
{
    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/19
     * @Description:原子更新器，这个原子更新器更新的就是gatingSequences数组，gatingSequences就是该类
     * 的一个成员变量，用于寻找消费者中最慢的那个消费进度
     */
    private static final AtomicReferenceFieldUpdater<AbstractSequencer, Sequence[]> SEQUENCE_UPDATER =
            AtomicReferenceFieldUpdater.newUpdater(AbstractSequencer.class, Sequence[].class, "gatingSequences");

    //环形数组的容量
    protected final int bufferSize;
    //消费者的等待策略
    protected final WaitStrategy waitStrategy;
    //生产者的当前进度，也就是生产者分配到第几个序号了
    protected final Sequence cursor = new Sequence(Sequencer.INITIAL_CURSOR_VALUE);
    //序号数组，这个数组中存储的都是消费者的消费进度，通过这个数组，就能找到所有消费者中，消费最慢的那个进度
    protected volatile Sequence[] gatingSequences = new Sequence[0];

    //构造方法
    public AbstractSequencer(int bufferSize, WaitStrategy waitStrategy)
    {
        //环形数组的容量小于1直接抛出异常
        if (bufferSize < 1)
        {
            throw new IllegalArgumentException("bufferSize must not be less than 1");
        }
        //Integer.bitCount方法的作用就是计算一个整数的二进制中有多少个1
        //单看这个好像没什么用，但是有一点大家一定要注意，那就是凡是2的n次幂的数，其二进制中1的个数永远是1
        //所以下面才会判断是不是等于1，如果不是1，说明环形数组的容量不是2的n次幂，那就无法使用长度-1做与运算的操作
        //计算相应的数组下标。其实从这里也能看到，一旦涉及到容量，在很多框架中容量为2的n次幂已经是一个标配了
        if (Integer.bitCount(bufferSize) != 1)
        {
            //数组容量不符合要求就直接抛异常
            throw new IllegalArgumentException("bufferSize must be a power of 2");
        }
        //在这里给环形数组容量和等待策略赋值
        this.bufferSize = bufferSize;
        this.waitStrategy = waitStrategy;
    }

    //得到当前生产者的序号
    @Override
    public final long getCursor()
    {
        return cursor.get();
    }

    //获取环形数组的容量
    @Override
    public final int getBufferSize()
    {
        return bufferSize;
    }

    //把新添加进来的消费者的消费序号添加到gatingSequences数组中
    @Override
    public final void addGatingSequences(Sequence... gatingSequences)
    {
        SequenceGroups.addSequences(this, SEQUENCE_UPDATER, this, gatingSequences);
    }

    //从gatingSequences数组中删除不必在关注的消费者的消费序号
    @Override
    public boolean removeGatingSequence(Sequence sequence)
    {
        return SequenceGroups.removeSequence(this, SEQUENCE_UPDATER, sequence);
    }

    //得到所有消费者序号和当前生产者序号中最小的那个序号
    @Override
    public long getMinimumSequence()
    {
        return Util.getMinimumSequence(gatingSequences, cursor.get());
    }

    //为消费者创建序号屏障
    @Override
    public SequenceBarrier newBarrier(Sequence... sequencesToTrack)
    {
        return new ProcessingSequenceBarrier(this, waitStrategy, cursor, sequencesToTrack);
    }

//    @Override
//    public <T> EventPoller<T> newPoller(DataProvider<T> dataProvider, Sequence... gatingSequences)
//    {
//        return EventPoller.newInstance(dataProvider, this, new Sequence(), cursor, gatingSequences);
//    }

    @Override
    public String toString()
    {
        return "AbstractSequencer{" +
                "waitStrategy=" + waitStrategy +
                ", cursor=" + cursor +
                ", gatingSequences=" + Arrays.toString(gatingSequences) +
                '}';
    }
}