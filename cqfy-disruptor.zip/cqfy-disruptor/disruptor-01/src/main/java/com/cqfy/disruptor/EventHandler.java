package com.cqfy.disruptor;


//消费者的事件处理器，专门用来处理生产者发布的数据的
public interface EventHandler<T>
{

    void onEvent(T event, long sequence, boolean endOfBatch) throws Exception;
}