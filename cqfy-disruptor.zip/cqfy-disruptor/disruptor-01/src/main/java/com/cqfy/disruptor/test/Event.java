package com.cqfy.disruptor.test;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/8
 * @Description:这个就是消费者要消费的事件，在以往的框架中，程序内部都会定义一个函数式接口暴露给用户
 * 让用户来定义事件或者任务等等，总之，程序会为你设计一些规则，并且通过一些接口告诉你这些规则
 * 但是在disruptor框架中，程序确实设计了规则，但是并没有通过接口告诉你，需要用户自行了解并熟悉程序的构造原理
 * 这也算是该框架的使用门槛之一吧
 */
public class Event<T> {

    private T data;

    public T getData() {
        return data;
    }

    public Event<T> setData(T data) {
        this.data = data;
        return this;
    }
}
