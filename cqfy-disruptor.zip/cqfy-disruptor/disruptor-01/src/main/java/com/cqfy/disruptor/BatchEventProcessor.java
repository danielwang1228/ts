package com.cqfy.disruptor;

import java.util.concurrent.atomic.AtomicInteger;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/19
 * @Description:非常重要的一个类了，这个类就是用来包装用户定义的每一个消费handler的，同时这个类的对象也是一个Runnable
 * 要交给线程来执行
 */
public final class BatchEventProcessor<T>
        implements EventProcessor
{
    //空闲状态
    private static final int IDLE = 0;
    //停止状态
    private static final int HALTED = IDLE + 1;
    //运行状态
    private static final int RUNNING = HALTED + 1;

    //该处理器的运行状态，初始默认为空闲状态
    private final AtomicInteger running = new AtomicInteger(IDLE);
    //异常处理器
    private ExceptionHandler<? super T> exceptionHandler = new FatalExceptionHandler();
    //这个成员变量会被环形数组赋值
    private final DataProvider<T> dataProvider;
    //序号屏障，每一个消费者都有一个序号屏障
    private final SequenceBarrier sequenceBarrier;
    //用户定义的消费handler，在该类的run方法中，其实执行的也是该handler中实现的方法
    private final EventHandler<? super T> eventHandler;
    //消费者的消费序号，其实就是消费的进度
    private final Sequence sequence = new Sequence(Sequencer.INITIAL_CURSOR_VALUE);
    //超时处理器，这个是可以让用户自己定义的，相当于一个扩展点
    private final TimeoutHandler timeoutHandler;
    //消费者开始真正工作时的一个回调接口，其实也是一个扩展点
    //用户可以定义这个接口的实现类，在消费者开始工作的时候，执行该接口实现类中定义的方法
    private final BatchStartAware batchStartAware;

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/19
     * @Description:构造方法，这个构造方法中有许多参数，我在这里就不一一解释了，大家尽可以顺着该类创建的逻辑
     * 看看传进来的参数都是哪些
     */
    public BatchEventProcessor(
            final DataProvider<T> dataProvider,
            final SequenceBarrier sequenceBarrier,
            final EventHandler<? super T> eventHandler)
    {
        this.dataProvider = dataProvider;
        this.sequenceBarrier = sequenceBarrier;
        this.eventHandler = eventHandler;
        //暂且注释掉
//        if (eventHandler instanceof SequenceReportingEventHandler)
//        {
//            ((SequenceReportingEventHandler<?>) eventHandler).setSequenceCallback(sequence);
//        }
        //这里可以看到，BatchStartAware和TimeoutHandler接口都是可以让消费handler一起实现的
        //也就是说消费handler可以同时实现好几个接口，这种对用户暴露接口的方式还是挺不常见的，一般都是框架内部使用
        //当然，这和Spring中的扩展点是一个道理，但Spring中的扩展点，也一般是在框架内部使用，尤其是程序员开发的某个框架
        //要和Spring集成的时候，可以让一个类同时实现多个接口，一般不会让用户直接这么做
        batchStartAware =
                (eventHandler instanceof BatchStartAware) ? (BatchStartAware) eventHandler : null;
        timeoutHandler =
                (eventHandler instanceof TimeoutHandler) ? (TimeoutHandler) eventHandler : null;
    }

    //得到当前消费者的消费进度，序号就是进度
    @Override
    public Sequence getSequence()
    {
        return sequence;
    }

    //终止该消费处理器的运行
    @Override
    public void halt()
    {
        //因为要终止了，所以先把状态改为停止状态
        running.set(HALTED);
        //这里会把阻塞的消费处理器唤醒，然后去响应这个终止的状态，就像是线程中断
        //注意，在第一个版本，大家顺着这个方法点进去，会发现最后在等待策略的实现类中，signalAllWhenBlocking
        //方法是一个空实现，实际上在程序中有很多等待策略，我还没有为大家引入，后面会依次引入的
        sequenceBarrier.alert();
    }

    //判断该处理器是否正在运行
    @Override
    public boolean isRunning()
    {
        return running.get() != IDLE;
    }

    //为该消费处理器设置异常处理器
    public void setExceptionHandler(final ExceptionHandler<? super T> exceptionHandler)
    {
        if (null == exceptionHandler)
        {
            throw new NullPointerException();
        }

        this.exceptionHandler = exceptionHandler;
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/19
     * @Description:这个就是该类的核心方法了，线程一旦执行，就会执行这个run方法
     */
    @Override
    public void run()
    {
        //既然消费者线程已经启动了，就要把消费处理器的状态设置成运行状态了
        if (running.compareAndSet(IDLE, RUNNING))
        {
            //先把消费者的中断状态设置为false
            sequenceBarrier.clearAlert();
            //这里会检查消费handler是否同时也实现了LifecycleAware接口
            //如果实现了这个接口，也会进行这个接口方法的回调，也是一个扩展点
            notifyStart();
            try
            {
                //再次判断状态是否正确
                if (running.get() == RUNNING)
                {   //如果状态正确，就执行真正的处理
                    processEvents();
                }
            }
            finally
            {
                //这里会再次执行LifecycleAware接口中的方法，LifecycleAware接口中一共有两个方法
                //一个是onStart，一个是onShutdown方法，一个在执行真正的消费者事件之前执行
                //一个在执行事件完之后执行，从这里也能看出来，这个接口有点生命周期的意思
                notifyShutdown();
                //消费事件都执行完了，所以也可以把消费处理器的状态设置成空闲状态了
                running.set(IDLE);
            }
        }
        else
        {
            //说实话，我还没想明白这里为什么有这样一个判断
            //按说在这个消费者处理器中，一个处理器对应的就是一个线程，不明白为什么会有这样一个判断，好像在这个线程
            //执行消费处理器之前，已经有另一个线程把这个消费处理器启动了，除非这个消费处理器可以复用
            //如果非要找一个原因，我更愿意相信这行代码起到的是拖底的作用
            //因为你不知道用户到底会对你的代码搞什么，万一用户就是把你这个消费处理器交给好几个线程同时执行呢？
            //毕竟消费处理器是一个Runnable
            if (running.get() == RUNNING)
            {
                throw new IllegalStateException("Thread is already running");
            }
            else
            {
                //走到这里显然没有执行消费事件，但是生命周期接口定义的方法还是要执行一下，让用户知道
                //因为生命周期接口的方法都执行了，但消费事件没有执行，这就是失败了呀
                earlyExit();
            }
        }
    }

    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/19
     * @Description:该类中最核心的方法，就是真正执行消费者逻辑的方法，从这个方法中，也能明白为什么这个类叫做
     * BatchEventProcessor，翻译过来就是批处理事件处理器的意思，因为是让一个线程把所有的生产者事件都给消费了
     * 所以才叫批处理，所以由此大家应该也能想到，既然有单线程消费所有生产者事件的情况，那有没有多线程共同消费
     * 生产者事件的情况呢？比如说每个线程消费一部分生产者事件？当然是有的，后面的版本我们就会讲到了
     */
    private void processEvents()
    {
        //先定义要消费的事件
        T event = null;
        //sequence是当前消费者自身的消费进度，这个get方法得到的就是当前的消费进度
        //因为消费进度是long整数，所以要+1L，这样就能得到下一个应该消费的进度了
        //举个例子，现在环形数组中前5个索引位置都有待消费的事件
        //当前消费者消费到第3个了，那么加一得到的就是第四个
        long nextSequence = sequence.get() + 1L;
        //在一个循环中开始执行真正的消费任务了
        while (true)
        {
            try
            {
                //这里以nextSequence当作参数，从序号屏障中获得最大的可以消费的序号
                //再举个例子，当前的消费者消费到第3个生产者发布的事件了，马上要去消费第四个，所以就把四当作参数
                //让序号屏障去判断生产者发布的事件是不是比4还要多。如果现在生产者已经发布了8个事件
                //那么就返回8，这就意味着环形数组中8和8之前的事件都可以被消费了，当然是被当前的消费者批量消费
                //如果没有发布那么多，或者说只发布到第4个了，那就把4原样返回就行
                //这里大家应该也认识到序号屏障的作用了，就是协调消费者和生产者的关系，保证消费者能消费已发布的事件
                //如果生产者还没有发布事件，消费者肯定不能消费
                final long availableSequence = sequenceBarrier.waitFor(nextSequence);
                if (batchStartAware != null)
                {
                    //这就是刚才提到的一个扩展接口，在消费者开始工作的时候，这个接口中定义的方法会被回调
                    //这个接口中的方法参数就是本次批处理的事件的个数
                    batchStartAware.onBatchStart(availableSequence - nextSequence + 1);
                }
                //下面就是批处理的逻辑了，在一个循环中判断，直到消费者要消费的进度等于刚才返回的最大的进度，就意味着
                //不能再消费了，因为生产者可能还没有继续发布事件
                while (nextSequence <= availableSequence)
                {   //之前在构造方法中说过，其实dataProvider就是环形数组
                    //这里就是根据序号从环形数组中把生产者发布的事件取出来消费
                    event = dataProvider.get(nextSequence);
                    //真正消费事件的方法，就是我在测试类中定义的SimpleEventHandler
                    eventHandler.onEvent(event, nextSequence, nextSequence == availableSequence);
                    //下一个要消费的进度加1
                    nextSequence++;
                }
                //消费完了之后，再把当前消费者的消费进度赋值成最新的
                sequence.set(availableSequence);
            }
            //下面之所以会出现异常，是因为上看调用的sequenceBarrier.waitFor(nextSequence)这行代码
            //因为序号屏障的waitFor方法会抛出异常，就是下面这个方法
            //long waitFor(long sequence) throws AlertException, InterruptedException, TimeoutException;
            catch (final TimeoutException e)
            {   //超时异常，就用TimeoutHandler来处理，当然，前提是用户创建的handler同时也实现了这个接口
                notifyTimeout(sequence.get());
            }
            catch (final AlertException ex)
            {   //如果序号屏障获得最大的可消费进度的过程中发现要中断消费者工作，那么就退出当前的循环
                if (running.get() != RUNNING)
                {
                    break;
                }
            }
            catch (final Throwable ex)
            {
                //这个就是普通的异常了，用户设置的异常处理器，就是用来处理这个异常的
                //这里我要多解释一句，如果是用户自己定义的异常处理器，这个方法可能实现的比较普通，并不会抛出异常，程序也就不会受到影响仍然会进入下一轮循环
                //如果是用程序默认的FatalExceptionHandler异常处理器，在handleEventException方法中，处理异常的过程中
                //会再次抛出异常  throw new RuntimeException(ex) 就像这样
                //可是现在并没有catch再抓住这个异常了，所以当前消费者就会直接被强制终止了，这就是为什么要暴露给用户一个接口
                //让用户自己去定义一个异常类
                exceptionHandler.handleEventException(ex, nextSequence, event);
                //处理异常之后，会发现把当前要消费进度更新到sequence中了，这也就意味着，一旦出现异常
                //虽然将要消费的事件还未消费，但是程序内部会默认为已经消费了，总之，会跳过这个事件了
                sequence.set(nextSequence);
                nextSequence++;
            }
        }
    }

    //该方法就是用来回调LifecycleAware接口中的方法的
    private void earlyExit()
    {
        notifyStart();
        notifyShutdown();
    }

    //处理超时异常的方法
    private void notifyTimeout(final long availableSequence)
    {
        try
        {
            if (timeoutHandler != null)
            {
                timeoutHandler.onTimeout(availableSequence);
            }
        }
        catch (Throwable e)
        {
            exceptionHandler.handleEventException(e, availableSequence, null);
        }
    }

    //回调LifecycleAware接口的onStart方法
    private void notifyStart()
    {
        if (eventHandler instanceof LifecycleAware)
        {
            try
            {
                ((LifecycleAware) eventHandler).onStart();
            }
            catch (final Throwable ex)
            {
                exceptionHandler.handleOnStartException(ex);
            }
        }
    }

    //回调LifecycleAware接口的onShutdown方法
    private void notifyShutdown()
    {
        if (eventHandler instanceof LifecycleAware)
        {
            try
            {
                ((LifecycleAware) eventHandler).onShutdown();
            }
            catch (final Throwable ex)
            {
                exceptionHandler.handleOnShutdownException(ex);
            }
        }
    }
}

