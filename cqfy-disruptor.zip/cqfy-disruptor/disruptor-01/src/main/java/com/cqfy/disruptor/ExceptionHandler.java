package com.cqfy.disruptor;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/19
 * @Description:异常处理器的接口
 */
public interface ExceptionHandler<T>
{

    void handleEventException(Throwable ex, long sequence, T event);


    void handleOnStartException(Throwable ex);


    void handleOnShutdownException(Throwable ex);
}
