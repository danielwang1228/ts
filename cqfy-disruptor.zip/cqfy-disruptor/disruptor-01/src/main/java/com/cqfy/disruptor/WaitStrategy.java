package com.cqfy.disruptor;

//等待策略的接口
public interface WaitStrategy
{
    long waitFor(long sequence, Sequence cursor, Sequence dependentSequence, SequenceBarrier barrier)
            throws AlertException, InterruptedException, TimeoutException;


    void signalAllWhenBlocking();
}
