package com.cqfy.disruptor;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/22
 * @Description:EventHandler对象的一个扩展接口
 */
public interface BatchStartAware
{
    //参数就是这次一共要消费的事件的个数
    void onBatchStart(long batchSize);
}