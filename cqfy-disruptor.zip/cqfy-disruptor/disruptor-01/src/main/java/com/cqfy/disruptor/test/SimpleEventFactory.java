package com.cqfy.disruptor.test;

import com.cqfy.disruptor.EventFactory;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/8
 * @Description:简单的事件工厂，该工厂就是用来在程序内部创建事件对象的
 * 这些被创建好的事件对象就会被存放到环形数组中，作为环形数组初始化时存放的数据
 */
public class SimpleEventFactory<T> implements EventFactory<Event<T>> {

    @Override
    public Event<T> newInstance() {
        return new Event<>();
    }
}
