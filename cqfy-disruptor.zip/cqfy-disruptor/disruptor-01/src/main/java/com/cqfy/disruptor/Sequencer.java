package com.cqfy.disruptor;


/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/19
 * @Description:序号生成器接口
 */
public interface Sequencer extends Cursored, Sequenced
{
    //程序中默认的初始序号，不管是生产者的序号还是消费者的序号，当它们刚刚初始化的时候，序号都默认为-1
    long INITIAL_CURSOR_VALUE = -1L;

    //将生产者的进度序号指定为sequence
    void claim(long sequence);

    //判断一个序号是否是可用的
    boolean isAvailable(long sequence);

    //把新添加进来的消费者的消费序号添加到gatingSequences数组中
    void addGatingSequences(Sequence... gatingSequences);

    //从gatingSequences数组中删除不必在关注的消费者的消费序号
    boolean removeGatingSequence(Sequence sequence);

    //为消费者创建序号屏障
    SequenceBarrier newBarrier(Sequence... sequencesToTrack);

    //得到所有消费者序号和当前生产者序号中最小的那个序号
    long getMinimumSequence();

    //得到已经发布的最大的生产者序号，而且还要保证最大生产者序号之前的序号都是连续的
    long getHighestPublishedSequence(long nextSequence, long availableSequence);

    //这个方法用不到，就先注释掉了
    //<T> EventPoller<T> newPoller(DataProvider<T> provider, Sequence... gatingSequences);
}