package com.cqfy.disruptor;

public interface EventSequencer<T> extends DataProvider<T>, Sequenced
{

}