package com.cqfy.disruptor;
/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/18
 * @Description:该接口的实现类就是用来包装消费者的handler的
 */
public interface EventProcessor extends Runnable
{
    Sequence getSequence();

    void halt();

    boolean isRunning();
}
