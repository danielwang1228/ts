package com.cqfy.disruptor.dsl;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadFactory;

/**
 * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
 * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
 * @Date:2023/8/17
 * @Description:该类就是用来给消费者创建线程的。每一个消费者都会被包装成EventProcessor对象
 * 而EventProcessor对象实际上继承了Runnable接口，所以在该类中就可以创建一个新的线程，然后把EventProcessor
 * 对象当作任务交给线程来执行
 */
public class BasicExecutor implements Executor
{
    //创建线程的工厂
    private final ThreadFactory factory;
    //该成员变量存储了创建的所有消费者线程，其实也没什么特别重要的意义
    //在该类的dumpThreadInfo方法中，会为存储的这些线程设置一些信息，方便toString时候输出
    private final Queue<Thread> threads = new ConcurrentLinkedQueue<>();

    //构造方法
    public BasicExecutor(ThreadFactory factory)
    {
        this.factory = factory;
    }


    /**
     * @author:B站UP主陈清风扬，从零带你写框架系列教程的作者，个人微信号：chenqingfengyangjj。
     * @Description:系列教程目前包括手写Netty，XXL-JOB，Spring，RocketMq，Javac，JVM等课程。
     * @Date:2023/8/17
     * @Description:真正执行消费者任务的方法
     */
    @Override
    public void execute(Runnable command)
    {
        //在这里创建了一个新线程，并且执行了Runnable任务
        //其实这里的Runnable任务就是EventProcessor对象
        final Thread thread = factory.newThread(command);
        if (null == thread)
        {
            throw new RuntimeException("Failed to create thread to run: " + command);
        }
        //启动线程
        thread.start();
        //把线程添加到队列中
        threads.add(thread);
    }

    @Override
    public String toString()
    {
        return "BasicExecutor{" +
                "threads=" + dumpThreadInfo() +
                '}';
    }

    private String dumpThreadInfo()
    {
        final StringBuilder sb = new StringBuilder();
        final ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        for (Thread t : threads)
        {
            ThreadInfo threadInfo = threadMXBean.getThreadInfo(t.getId());
            sb.append("{");
            sb.append("name=").append(t.getName()).append(",");
            sb.append("id=").append(t.getId()).append(",");
            sb.append("state=").append(threadInfo.getThreadState()).append(",");
            sb.append("lockInfo=").append(threadInfo.getLockInfo());
            sb.append("}");
        }
        return sb.toString();
    }
}
