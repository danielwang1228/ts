package com.cqfy.disruptor;


//事件传输器，就是将生产者发布的数据，传输到对应的Event对象中
//这个是把多个数据传输到Event对象中
public interface EventTranslatorVararg<T>
{

    void translateTo(T event, long sequence, Object... args);
}
