package com.cqfy.disruptor.dsl;


//生产者的类型枚举类
public enum ProducerType
{
    //单生产者模式
    SINGLE,

    //多生产者模式
    MULTI
}